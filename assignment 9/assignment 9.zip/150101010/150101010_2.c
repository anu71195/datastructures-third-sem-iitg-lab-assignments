//NAME : ANURAG RAMTEKE
//ROLL NO : 150101010
#include <stdio.h>
#include <stdlib.h>

typedef struct node node;
struct node
{
	node *parent;
	node*left;
	node*right;
	node*child;
	int key;
	int mark;
	int degree;
};
node* make_fib_heap()//makes the basic node which will be NULL
{
	node * temp;
	temp=NULL;
	return temp;
}
node*find_min(node*temp)//find the node with the minimum value in the double circularl linked list and then return it
{
	node * temp3,*temp2;
	temp3=temp;
	temp2=temp;
	int min=temp3->key;
	temp3=temp3->right;
	while(temp3!=temp)//to do that it traverses the entire linked list and then find the minimum and then returns it
	{
		if((temp3->key)<min)	
		{
			temp2=temp3;
			min=temp2->key;
		}
		temp3=temp3->right;
	}
	temp=temp2;
	return temp;
}
node*min_degree(node * temp)//gives the node in the linked list with the minimum degree
{
	node * temp3,*temp2;
	temp3=temp;
	temp2=temp;
	int min=temp3->degree;
	temp3=temp3->right;
	while(temp3!=temp)//to do that it traverses the entire linked list and then find the node with the minimum degree adn then returns it
	{
		if((temp3->degree)<min)	
		{
			temp2=temp3;
			min=temp2->degree;
		}
		temp3=temp3->right;
	}
	temp=temp2;
	return temp;
}
node*max_degree(node*temp,int *flag)//gives the node in the linked list with the maximum degree and flag is such that marked nodes won't be taken into account and flag is 1 when it is last node in the linked which is going to be returned otherwise it will be 0
{
	int n,i=0;
	n=number_of_nodes(temp);
	node * temp3,*temp2;
	if(temp->right ==temp) 
	{
		*flag =1;
		if(temp->mark==0) return temp;
		else return NULL;
	}
	temp3=temp->right;
	temp2=NULL;
	if(temp->mark==1) i++;
	if (i==n-1) *flag = 1;
	int max=0;
	while(temp3 !=temp)//to do that it traverses the entire linked list and then find the node with the maximum degree adn then returns it
	{
		if(temp3->mark ==1) i++; if (i==n-1) *flag = 1;
		if((temp3->degree)>=max &&temp3->mark==0)	
		{
			temp2=temp3;
			max=temp2->degree;
		}
		
		temp3=temp3->right;
	}
	if(temp->mark==0 && (temp->degree)>=max) return temp;
	temp=temp2;
	return temp;
}
node*create_node(int x)//createsa node with the key equals to x
{
	node*temp;
	temp=(node*)malloc(sizeof(node));
	temp->key=x;
	temp->parent=NULL;
	temp->left=temp;
	temp->right=temp;
	temp->child=NULL;
	temp->mark=0;
	temp->degree=0;
	return temp;
}
int number_of_nodes(node*link)//returns the number no of nodes in link
{ 
	node * temp =link;
	int i=1;
	temp=temp->right;
	while(temp!=link)//looping through all the nodes and then increament i to give the total nodes of nodes 
	{ 
		i++;
		temp=temp->right;
	} 
	return i;
}
node* concat(node*link1,node*link2)//concats list link1 and link2 and returns the pointers of the minimum key
{
	if(link1==NULL) return link2;
	link1->right->left=link2->left;
	link2->left->right=link1->right;
	link1->right=link2;
	link2->left=link1;
	if((link1->key)>(link2->key)) link1=link2;//putting the condition after concating such that the node with least key will be returned
	return link1;
	
}
node*UNION(node*link1,node*link2)//it concats the two linked list i.e. linked list link1 and link2and then returns the pointers of the minimum key
{
	node * temp;
	temp=concat( link1,link2);
	return temp;//concats list link1 and link2 and returns the pointers of the minimum key
}
node*fib_heap_insert(node*H,int x)//inserts the nodes x in the fibonacci heap H
{
	node*H1;
	H1=create_node(x);//creates node with the key x
	H=UNION(H,H1);//concats linked list H and H1
	return H;
	
}
void make_parent_null(node*temp)//makes the parents of linked list in all the nodes of the linked list whose pointer is temp to null
{
	node*temp2;
	temp2=temp;
	if(temp2==NULL) 
	{
		printf("\nERROR - 0 - NO CHILD\n\n");//if temp has is null
		return;
	}
	temp->parent=NULL;
	temp2->parent=NULL;
	temp2=temp2->right;
	while(temp2!=temp)//traverses throght he entire linked list to make the parent NULL
	{
		temp2->parent=NULL;
		temp2=temp2->right;
	}
}
node*extract(node*H,int print_option)	//extracts the nodes H and print option if 1 then prints the extracted value otherwise it won't
{
	node*temp,*temp2,*temp3;
	temp=H;
	if(print_option==1) if(H!=NULL) printf("\nThe extracted element is %d\n",temp->key);
	if(temp==NULL)
	{
		printf("\nERROR - 1 - EMPTY HEAP\n\n");//if empty heap then error
		return NULL;
	}
	
	if(temp->child==NULL)//case if there is no child of temp
	{
		if(temp->right==temp) return NULL;//if it is a single node		
		temp->left->right=temp->right;//deletes the extracted node form the linked list
		temp->right->left=temp->left;
		temp=temp->right;
		if(temp==temp->right) return temp;
		temp=find_min(temp); //find the node with the minimum value in the double circularl linked list and then return it
	}
	else//if it has child
	{
		if(temp->right==temp) //if the root list has only one node
		{
			//output[1]=temp->child;
			temp->child->parent=NULL;		
			return temp->child;
		}
		temp->left->right=temp->right;//deletes the extracted node form the linked list
		temp->right->left=temp->left;
		make_parent_null(temp->child);//makes the parent of child of extracted node to be NULL
		temp2=temp->child;
		temp3=find_min(temp->right);//find the node with the minimum value in the double circularl linked list and then return it
		temp=concat(temp2,temp3);//concats the linked list temp2 and temp3
	}
	//output[1]=temp;
	return temp;
}
node* create_child(node*link1,node*link2)//makes the Link2 link list child of first link1 list
{
	node*temp=link2;
	link2->parent=link1;
	temp=temp->right;
	while(temp!=link2)//looping through all the nodes of link 2 and makes it parent to the minimum key pointer of linked list 1
	{
		temp->parent=link1;
		temp=temp->right;
	}
	if(link1->child==NULL)	 	link1->child=link2;//if link1 child is null then simply link 2 will become its child otherwise it will be concated with the list of child of link1 already present
	else
	{
		node*temp2=link1->child;
		link1->child=concat(temp2,link2);
	}
 	link1->degree+=1; 
 	return link1;
}

node* HEAP_LINK(node*link,node*y,node *x)//removes y from the link list and joins it to the x as its child
{ 
	node*tempr=y->right;
	node*templ=y->left;
	node*temp;
	templ->right=tempr;
	tempr->left=templ;
	y->left=y;
	y->right=y;
	temp=create_child(x,y);//after removing y from lnked list making it the child of x
	node * temp3,*temp2;
	temp3=temp;
	temp2=temp;
	y->mark=0;//making its mark equal to 0

	if(link==y)//basiccase that is if the minimum term is the one which has to be removed then following operations will be done where we have fid the second minimum and then delete the minimum after joining it to the parent as per requirement and then  return the second minimum pointer
	{	
		temp=find_min(temp);//find the node with the minimum value in the double circularl linked list and then return it
		 
	}
	return temp;
}
int consolidate_heap(node*H)//makes the same degree nodes merged into one till no nodes is left such that some other nodes has same degree int he root list after doing  extraction procedure
{ 
	node * temp,*temp2;
	temp=H;	
	temp2=H;
	if(temp==temp->right) return 0;
	while(temp2->right!=H)//this is done by looping through all the nodes and finding if another nodes has same degree if it has then merge successful ones are returned with 1 and if there is no matching degree nodes then returned 0
	{
		temp=temp2->right;
		while(temp!=H)
		{
			if(temp2->degree==temp->degree)
			{
				if(temp2->key<temp->key)	HEAP_LINK(H,temp,temp2);
				else HEAP_LINK(H,temp2,temp);
				return 1;
			}
			temp=temp->right;
		}
		temp2=temp2->right;
	}
	return 0;
}

node*extract_min(node*H,int print_option)//extractsthe minimum from the heap and prints option is 1 when we want to print the extracted elements otherwise when it is zero it won't print extracted value
{
	int i=1;
	H=extract(H,print_option); //extracts the nodes H and print option if 1 then prints the extracted value otherwise it won't
	if(H==NULL) //case for empty heap gives error and then returns
	{
		printf("\nERROR - 2 - EMPTY HEAP\n\n");	
		return H;
	}
	while(i)	i=consolidate_heap(H);//makes the same degree nodes merged into one till no nodes is left such that some other nodes has same degree int he root list after doing  extraction procedure
	return H;	
}
 
void show_heap2(node*head,int depth)	//prints the heap in graphical form such that fibonacci heap is rotated 90 degress in this graphical form
{
	int i,n,flag=0;
	node*temp;
	temp=max_degree(head,&flag);//gives the node in the linked list with the maximum degree and flag is such that marked nodes won't be taken into account and flag is 1 when it is last node in the linked which is going to be returned otherwise it will be 0
	temp->mark=1; 
	if(temp==min_degree(temp)&&flag == 1)//last case in the linked list that is if the node is the minimum and flag is 1 flag shows that it is the last one and all the nodes in that linked list are marked
	{
		printf("%d\t",temp->key);
		temp->mark=0;//makes the mark zero once printed
		if(temp->child==NULL)//if the child is null then returned
		{
			printf("\n\n");
			 return;
		}
		else show_heap2(temp->child,depth+1);//prints the heap in recursive manner where the hea dwill becomes now its child
	}
	
	else 
	{
		show_heap2(temp,depth);//prints hte heap in recursive manner where the next biggest term to this is find out
		for(i=0;i<depth;i++) printf("        ");//spacing required to print the output properly	
		printf("%d\t",temp->key);			 
		temp->mark=0;//makes the mark zero once printed
		if(temp->child==NULL) 
		{
			printf("\n\n");	
			for(i=0;i<depth;i++) printf("       ");	
			if(temp->key == 3)  	
			return;
		}
		else show_heap2(temp->child,depth+1);//prints the heap in recursive manner where the head will becomes now its child
	}
	
 	 
}
int show_fib_heap(node* head)//prints the heap in graphical form
{
	node*H=head;
	printf("\nSTRUCTURE OF FIBONACCI HEAP (ROTATED 90 DEGRESS):\n\n");//the graphical form will be rotated 90 degrees 
	if(head==NULL)//if heap is empty then this condition
	{
		printf("HEAP IS EMPTY\n");
		return 0;
	}
	else		show_heap2(head,0); //otherwise it will show the heap
}
int main()
{
	
	node * H;
	FILE * fp;
	int type_of_input,type_of_fileinput,flag=1,insert_number,print_option=1;//type of input means whether the fileinput or userinput and types of file input means whether the file chose should be first, second or its name will be written manually
	char file_name[100],c;
	printf("0/1	:	user input/fileinput	:	");
	scanf("%d",&type_of_input);
	while(type_of_input>1)//in case of wrong input
	{
		printf("\nWRONG INPUT - GIVE THE INPUT AGAIN\n\n");
		printf("0/1	:	user input/fileinput	:	");
		scanf("%d",&type_of_input);
	}
	if(type_of_input==1)
	{
		printf("0/1/2	:	file 1/file 2/ type the file name	:	");
		scanf("%d",&type_of_fileinput);//types of file input means whether the file chose should be first, second or its name will be written manually
		while(type_of_fileinput>2)//in case of wrong input
		{
			printf("\nWRONG INPUT - GIVE THE INPUT AGAIN\n\n");
			printf("0/1/2	:	file 1/file 2/ type the file name	:	");
			scanf("%d",&type_of_fileinput);
		}
		if(type_of_fileinput==0) fp=fopen("test1.txt.txt","r");//opens first file
		else if(type_of_fileinput==1) fp = fopen("test2.txt.txt","r");//opens second file
		else if (type_of_fileinput==2)//opens the file whose name was written
		{
			printf("Give the file name	:	");
			scanf("%s",file_name);
			fp=fopen(file_name,"r");
		}
	}
	if(type_of_input==1)//if the option is fileinput
	{
		printf("\nPRINT OPTION IS BY DEFAULT ON\n");
		while(!feof(fp))//reads till the end of the file from the starting
		{
			fscanf(fp,"%c",&c); 
			if(c=='#') flag=0;//comments to be ignored case
			if(flag==0 && c=='\n') flag =1;//comment ended case
			if(flag==1)
			{
				if(c=='+')print_option=1;//print the extracted value or not case
				else if (c=='-')print_option=0;
				if(c=='c'||c=='i'||c=='e'||c=='u'||c=='S')//trivial cases as mentioned
				{
					if(c=='c') H=make_fib_heap();//makes the basic node which will be NULL
					else if(c=='i')
					{
						fscanf(fp,"%d",&insert_number); 
						H=fib_heap_insert(H,insert_number);//inserts the nodes x in the fibonacci heap H
					}
					else if ( c=='e') H=extract_min(H,print_option);//extractsthe minimum from the heap and prints option is 1 when we want to print the extracted elements otherwise when it is zero it won't print extracted value
					else if (c=='S') { show_fib_heap(H);}//prints the heap in graphical form
				}
			}
		}
	}
	else  //if the option is userinput
	{
		printf("\nPRINT OPTION IS BY DEFAULT ON\n");		
		while(1)
		{	
			printf("\nc/i///e/(s or S)///+/-	:	create/insert///extract_min/print/print option on/print option off	:	");
			while(1)
			{

				scanf("%c",&c); 
				if(c=='+') //print the extracted value or not case
				{
					print_option=1;			
					printf("\nPRINT OPTION IS NOW ON\n");
					printf("\nc/i///e/(s or S)///+/-	:	create/insert///extract_min/print/print option on/print option off	:	");

				}
				else if (c=='-') //print the extracted value or not case
				{
					print_option=0;
					printf("\nPRINT OPTION IS NOW OFF\n");
					printf("\nc/i///e/(s or S)///+/-	:	create/insert///extract_min/print/print option on/print option off	:	");

				}
				if(c=='c'||c=='i'||c=='e'||c=='u'||c=='S'||c=='s') break;	
			}
			 
			if(c=='c') H=make_fib_heap();//makes the basic node which will be NULL
			else if(c=='i')
			{
				printf("insert an element	:	");
				scanf("%d",&insert_number); 
				H=fib_heap_insert(H,insert_number); //inserts the nodes x in the fibonacci heap H
			}
			else if ( c=='e') {H=extract_min(H,print_option); if(H==NULL) return 0; } //extractsthe minimum from the heap and prints option is 1 when we want to print the extracted elements otherwise when it is zero it won't print extracted value
			else if (c=='S'||c=='s') { show_fib_heap(H);}//prints the heap in graphical form
		}
	}

}
