//NAME : ANURAG RAMTEKE
//ROLL NO : 150101010
#include <stdio.h>
#include <stdlib.h>

typedef struct node node;
struct node
{
	int key;
	int degree;
	node* parent;
	node* child;
	node* left;
	node* right;
	int mark;
};
node * Insert_Node(node*link,int k)	//inserts the node in the linked list with the value of the node to be inserted equals to k
{
	node*temp;
	temp=(node*)malloc(sizeof(node));
	temp->parent=NULL;
	temp->child=NULL;
	temp->mark=0;
	temp->degree=0;
	temp->key=k;
	if(link->left ==NULL&&link->right==NULL)
	{
		link->left=temp;
		link->right=temp;
		temp->left=link;
		temp->right=link;
		if((link->key)>(temp->key))link=temp;//putting the condition where after inserting the node checks which node is having smaller key and returns that node
	}
	else
	{
		temp->right=link->right;
		link->right->left=temp;
		link->right=temp;
		temp->left=link;
		if((link->key)>(temp->key))link=temp;//putting the condition where after inserting the node checks which node is having smaller key and returns that node
	}
	return link;
}
node* Create_List_Random(int length)//creates a random list of integers less than 100 and length of length
{
	int k,i;
	printf("Give the element");
	k=rand()%100;
	node*link;
	link=(node*)malloc(sizeof(node));
	link->parent=NULL;
	link->child=NULL;
	link->mark=0;
	link->degree=0;
	link->key=k;
	link->left=NULL;
	link->right=NULL;
	for(i=0;i<length-1;i++)
	{
		printf("Give the element");
		k=rand()%100;
		link=Insert_Node(link,k);//inserts the node in the linked list with the value of the node to be inserted equals to k
	}
	return link;
}
node* concat(node*link1,node*link2)	//concats list link1 and link2 and returns the pointers of the minimum key
{
	link1->right->left=link2->left;
	link2->left->right=link1->right;
	link1->right=link2;
	link2->left=link1;
	if((link1->key)>(link2->key)) link1=link2;//putting the condition after concating such that the node with least key will be returned
	return link1;
	
}
void print(node * link)	//prints the link with mark, key and degree
{
	node * temp =link;
	printf("\nLINKED LIST FORMED IS:\n\nkey\tdegree\tmark\n");
	printf(" %d\t  %d\t %d\n",link->key,link->degree,link->mark);
	temp=temp->right;
	while(temp!=link)				//looping through all the ndoes int the link list
	{
		printf(" %d\t  %d\t %d\n",temp->key,temp->degree,temp->mark);
		temp=temp->right;
	}
}
int number_of_nodes(node*link)	//returns the number no of nodes in link
{
	node * temp =link;
	int i=1;
	temp=temp->right;
	while(temp!=link)//looping through all the nodes and then increament i to give the total nodes of nodes 
	{
		i++;
		temp=temp->right;
	}
	return i;
}
node* create_child(node*link1,node*link2)//makes the Link2 link list child of first link1 list
{
	node*temp=link2;
	link2->parent=link1;
	temp=temp->right;
	while(temp!=link2)//looping through all the nodes of link 2 and makes it parent to the minimum key pointer of linked list 1
	{
		temp->parent=link1;
		temp=temp->right;
	}
	if(link1->child==NULL)	 	link1->child=link2;//if link1 child is null then simply link 2 will become its child otherwise it will be concated with the list of child of link1 already present
	else
	{
		node*temp2=link1->child;
		link1->child=concat(temp2,link2);
	}
 	link1->degree+=number_of_nodes(link2);//calculates and updates the degree of the nodes
 	return link1;
}
node* HEAP_LINK(node*link,node*y,node *x)//removes y from the link list and joins it to the x as its child  
{
	node*tempr=y->right;
	node*templ=y->left;
	node*temp;
	templ->right=tempr;
	tempr->left=templ;
	y->left=y;
	y->right=y;
	temp=create_child(x,y);//after removing y from lnked list making it the child of x
	node * temp3,*temp2;
	temp3=temp;
	temp2=temp;
	y->mark=0;//making its mark equal to 0
	if(link==y)//basiccase that is if the minimum term is the one which has to be removed then following operations will be done where we have fid the second minimum and then delete the minimum after joining it to the parent as per requirement and then  return the second minimum pointer
	{	
		int min=temp3->key;
		temp3=temp3->right;
		while(temp3!=temp)
		{
			if((temp3->key)<min)	
			{
				temp2=temp3;
				min=temp2->key;
			}
			temp3=temp3->right;
		}
		temp=temp2;
	}
	return temp;
}
node*find(int a,node*link)		//finds the address of the nodes with the key a
{
	node * temp=link;
	if(link->key==a) return link;
	temp=temp->right;
	while(temp!=link)	//looping through all the nodes and if found that a in the linked list then return it otherwise show error and then exit;
	{
		if(temp->key==a) return temp;
		temp=temp->right;
	}
	printf("ERROR");
	exit;
	
}
int main()
{
	node*L1,*L2,*L;//L1 is the link list 1, L2 is the link list 2 and L is the linked list formed by some manipulation oroperation on L1 or/and L2
	int length,number,option,option2,number2,a,b;//length is the  no of elements in the linked list 1
	printf("Give the no of elements in the linked list 1 : ");
	scanf("%d",&length);
	L1=Create_List_Random(length);//generates list of random numbers
	print(L1); //prints the linked list L1 with key, degree and mark
	number=number_of_nodes(L1);//gives the number of nodes in L1 
	printf("number of nodes in this root list is %d\n\n",number);
	printf("Give the no of elements in the linked list 2 : ");
	scanf("%d",&length);	
	L2=Create_List_Random(length);//generates list of random number  
	print(L2);//prints the linked list L2 with key, degree and mark
	number=number_of_nodes(L2);//gives the number of nodes in L2
	printf("number of nodes in this root list is %d\n\n",number);
	printf("0/1/2	:	concat/create_child/heap_link:");
	scanf("%d",&option);
	if(option==0)
	{
		L=concat(L1,L2);//concat list L1 and L2 and returns the minimum key pointer
		print(L);//prints the linked L with key , degree and mark
		number=number_of_nodes(L);//returns the number no of nodes in L
		printf("number of nodes in the root list is %d\n\n",number);	
	}
	else if(option==1)
	{
		printf("0/1	: make second link list child of first/make first link list child of second");
		scanf("%d",&option2);
		if(option2==0)L=create_child(L1,L2);//makes the L2 link list child of first link list
		else if(option2==1)L=create_child(L2,L1);//makes the L1 link list child of L2
		printf("The root list is :\n");
		print(L);//prints the linked L with key , degree and mark
		printf("The child list is :\n");
		print(L->child);//gives the child of L and the linked list left to right it is associated with
		number=number_of_nodes(L);//gives the number of nodes in the linked list L
		printf("number of nodes in the root list is %d\n\n",number);	
		number2=number_of_nodes(L->child);//gives the number of nodes of L->child linked list fromleft to right that it is associated with
		printf("number of nodes in the child list is %d\n\n",number2);	
	}
	else if(option==2)
	{
		printf("0/1	:	concat list/do not concat");
		scanf("%d",&a);
		if(a==0)
		{
			L=concat(L1,L2);//concat list L1 and L2 and returns the minimum key pointer
			print(L);//prints the linked L with key , degree and mark
			number=number_of_nodes(L);//gives the number of nodes in the linked list L
			printf("number of nodes in this root list is %d\n\n",number);
			printf("Give two nodes to heapify such that to remove first one from the root list:\n");
			scanf("%d %d",&a,&b);
			L=HEAP_LINK(L,find(a,L),find(b,L));//removes find(a,L) from the link list and joins it to the find (b,L) as its child where find(a,L) gives the address of node with key a
		}
		else if(a==1)
		{
			printf("0/1	:	List 1/ List 2");
			scanf("%d",&number2);
			printf("Give two nodes to heapify such that to remove first one from the root list:\n");
			scanf("%d %d",&a,&b);
			if(number2==0)
			{
				L=HEAP_LINK(L1,find(a,L1),find(b,L1));//removes find(a,L1) from the link list and joins it to the find (b,L1) as its child where find(a,L1) gives the address of node with key a
			}
			else if(number2==1)
			{
				L=HEAP_LINK(L2,find(a,L2),find(b,L2));//removes find(a,L2) from the link list and joins it to the find (b,L2) as its child where find(a,L2) gives the address of node with key a
			}
		}
		print(L);//prints the linked L with key , degree and mark
		print(find(b,L)->child);
		number=number_of_nodes(L);
		printf("number of nodes in this root list is %d\n\n",number);
	}
}
