//NAME - ANURAG RAMTEKE
//ROLL NO-150101010

#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
	int data;
	struct node * link;
}node;

node* createnode(int data)
{
	node * temp=malloc(sizeof(node));
	(*temp).data =data;
	(*temp).link=NULL;
	return temp;
}
void printLL(node * head)
{
	node * temp=head;
	int i=1;
	while(temp!=NULL) 
	{
		printf("node %d =%d\t",i++,(*temp).data);	;
		temp=(*temp).link;
	}
	printf("\n");
}
 
void push(node** headptr,node * now)
{
 
	(*now).link =*headptr;
	*headptr = now;
	
}
int pop(node * head)
{
	int flag=0;
	if((*head).link==NULL) flag =1;
	head=(*head).link;
	return flag;		
}
void main()
{
	node*  head,*now;
	int nodeData,pos,del,flag=0;
	char c,dummy;
	while(1)
	{	
		printf("type the data to create first node in the stacks:-\n");
		scanf("%d",&nodeData);
		head = createnode(nodeData);

		while(1)
		{
			scanf("%c",&dummy);
			printf("type e to the end program\ntype i to insert more values\ntype t to print the stacks\ntype p to delete a node:-\n");
			scanf("%c",&c);
			if(c=='e') return;
			else if (c=='i')
			{
				printf("put the data in the node:-\n");
				scanf("%d",&nodeData);
				now=createnode(nodeData);
				push(&head,now);
			}
			else if (c=='p')
			{
				flag =pop(head);
			}
			else if (c=='t')printLL(head);
			if (flag ==1) break;
		}
		flag =0;	
	}
	
}
