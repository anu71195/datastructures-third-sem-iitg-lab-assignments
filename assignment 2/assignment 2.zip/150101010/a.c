//NAME - ANURAG RAMTEKE
//ROLL NO-150101010


#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
	int data;
	struct node * link;
}node;

node* createnode(int data)
{
	node * temp=malloc(sizeof(node));
	(*temp).data =data;
	(*temp).link=NULL;
	return temp;
}
void printLL(node * head)
{
	node * temp=head;
	int i=1;
	while(temp!=NULL) 
	{
		printf("node %d =%d\t",i++,(*temp).data);	;
		temp=(*temp).link;
	}
	printf("\n");
}
int totalNodes(node *head)
{
	int i=1;
	node * temp=head;
	while(1)
	{
		temp=(*temp).link;
		if(temp==NULL) break;
		i++;
	}
	return i;
}

void nodeend(node * head, node * now)
{
	node * temp = head;
	while((*temp).link!=NULL) temp=(*temp).link;
	(*temp).link = now;
	return; 
}
void nodebetween(node * head, node * now,int pos)
{
	node * temp=head;
	int i=1;
	while(i<pos-1)
	{
		temp=(*temp).link;
		i++;
	}
	(*now).link=(*temp).link;
	(*temp).link=now;
}
void nodestart(node** headptr,node * now)
{
	(*now).link =*headptr;
	*headptr = now;
}
void insertNode(node* head,node * now,int pos)
{

	if(pos==1){	nodestart(&head,now); }
	else if(pos==totalNodes(head)+1) nodeend(head,now);
	else if (pos>totalNodes(head)+1) printf("ERROR!! empty nodes before this position in the linkedlist");
	else nodebetween(head, now,pos);
}
void delStart(node * head)
{
	head=(*head).link;
}
void delEnd(node * head)
{
	int k=0,i=0;
	node * temp = head;
	while((*temp).link!=NULL) 
	{
		temp=(*temp).link;
		k++;
	}
	temp = head;
	while(i<k-1) 
	{
		temp=(*temp).link;
		i++;
	}
	(*temp).link = NULL;
}
void delBetween(node * head, int pos)
{
	int k=1;
	node * temp = head;
	while(k<pos-1) 
	{
		temp=(*temp).link;
		k++;
	}
	(*temp).link = NULL;
}
int deleteNode(node * head, int del)
{
	int flag =0;
	if((*head).link ==NULL)		
	{
		printf("EMPTY STACK\n");
		head=NULL;
		flag =1;
	}
	else if(del==1) delStart(head);
	else if(del==totalNodes(head)) delEnd(head);
	else if(del>totalNodes(head)) printf("ERROR!! no node is present at this position");
	else delBetween(head,del);
	return flag;
}
void main()
{
	node*  head,*now;
	int nodeData,pos,del,flag;
	char c,dummy;
	while(1)
	{	
		printf("type the data to create first node in the linked list:-\n");
		scanf("%d",&nodeData);
		head = createnode(nodeData);

		while(1)
		{
			scanf("%c",&dummy);
			printf("type e to the end program\ntype i to insert more values\ntype p to print the linked list\ntype d to delete a node:-\n");
			scanf("%c",&c);
			if(c=='e') return;
			else if (c=='i')
			{
				printf("put the data in the node:-\n");
				scanf("%d",&nodeData);
				now=createnode(nodeData);
				printf("put the position to insert node:-\n");
				scanf("%d",&pos);
				insertNode(head, now, pos);
			}
			else if (c=='d')
			{
				printf("put the position of the node you want to delete:-\n");
				scanf("%d",&del);
				flag =deleteNode(head,del);
			}
			else if (c=='p')printLL(head);
			if (flag ==1) break;
		}	
	}
}
