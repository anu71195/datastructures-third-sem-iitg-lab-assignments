//NAME - ANURAG RAMTEKE
//ROLL NO-150101010

	#include<stdio.h>
	#include<stdlib.h>
//Some convenience functions-
void retur(int x){printf("%d",x);}
void returs(char* x){printf("%s",x);}
void returN(){printf("\n");}
void returT(){printf("\t");}
void returA(int A[],int n){int i=0;while(i<n)printf("%2d ",A[i++]);returN();}
int take()
{
	int n;
	scanf("%d",&n);
	return n;
}

void randomInput(int A[],int n)
{								//generates random numbers
	for(int t=0;t<n;t++)A[t]=random()%100; 			//for less space in terminal. remove if wanted.
}
void takeInput(int A[],int n)
{ //take User input
	returs("Enter elements -");for(int t=0;t<n;t++)A[t]=take();
}
struct node 
{
	int data;
	struct node* next;
} ;

void printLL(struct node* head)
{
	while(head!=NULL){retur(head->data);returs(" ");head=head->next;}
	returN();
}

int checkNULL(struct node* head)
{
	if(head==NULL)returs("Head is NULL.\n");
	return head==NULL;
}

struct node* createNode(int val)
{
	struct node* t=malloc(sizeof(struct node));
	t->data=val;
	t->next=NULL;
	return t;
}

void createStack(int A[],int n, struct node* head)
{
	returs("Stack :  \t");
	if(checkNULL(head))return;
	struct node* head1=head;//for printing
	
	for(int i=1;i<n;i++)
	{
		struct node* t;
		t=createNode(A[i]);
		head->next=t;
		head=head->next;
	}
	printLL(head1);
}

void Pop(struct node **headptr)
{
	struct node* toDelete=*headptr;  
	if(checkNULL(toDelete))return;
	*headptr=toDelete->next;
	free(toDelete);
}

void Push(struct node **headptr,int val)
{
	struct node* t=createNode(val);
	t->next=*headptr;  //"insert"
	*headptr=t;
}


void OUTPUT1(int A[],int n)
{
	int S[n]; //max number of elements
	int i=0;
	for(int i=0;i<n;i++)
	{
		int op=A[i],now=1;
		for(int j=i-1;j>=0;j--)
		{
			if(A[j]>op)break;
			else now++;
		}
		S[i]=now;
	}
	returs("Output array with n^2 time complexity:-\n");returT();returA(S,n);
}

int top(struct node* a){return a->data;}

void OUTPUT2(int A[],int n)
{
	struct node* a=malloc(sizeof(struct node));
	int S[n]; //max number of elements
	int i=0;
	for(int i=0;i<n;i++)
	{
		while( a!=NULL && A[top(a)] <= A[i])
		{
			Pop(&a);
		}
		if((a==NULL))
		{
			S[i]=i+1;
		}
		else 
		{
			S[i]=i-top(a);
		}
		Push(&a,i);
	}
	returs("Output array with n time complexity:-\n");returT();returA(S,n);
}

int main()
{
	int random=1,n=5;
	returs("Enter length of the array : ");
	n=take();
	int *A=malloc(sizeof(int)*n);
	int *index=malloc(sizeof(int)*n);
	returs("User input or randomInput? (0/1)");
	random=take(); 
	if(random)randomInput(A,n);
	else takeInput(A,n);
	returs("Generated Array: ");
	returT();
	returA(A,n);
	OUTPUT1(A,n);
	returN();
	OUTPUT2(A,n);
	return 0;
}
