//NAME - ANURAG RAMTEKE
//ROLL NO-150101010

#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
	int data;
	struct node * link;
}node;

node* createnode(int data)
{
	node * temp=malloc(sizeof(node));
	(*temp).data =data;
	(*temp).link=NULL;
	return temp;
}
void printLL(node * head)
{
	node * temp=head;
	int i=1;
	while(temp!=NULL) 
	{
		printf("node %d =%d\t",i++,(*temp).data);	;
		temp=(*temp).link;
	}
	printf("\n");
}
int totalNodes(node *head)
{
	int i=1;
	node * temp=head;
	while(1)
	{
		temp=(*temp).link;
		if(temp==NULL) break;
		i++;
	}
	return i;
}

void nodeend(node * head, node * now)
{
	node * temp = head;
	while((*temp).link!=NULL) temp=(*temp).link;
	(*temp).link = now;
	return; 
}
void nodebetween(node * head, node * now,int pos)
{
	node * temp=head;
	int i=1;
	while(i<pos-1)
	{
		temp=(*temp).link;
		i++;
	}
	(*now).link=(*temp).link;
	(*temp).link=now;
}
void nodestart(node** headptr,node * now)
{
	(*now).link =*headptr;
	*headptr = now;
}
void insertNode(node* head,node * now,int pos)
{

	if(pos==1){	nodestart(&head,now); }
	else if(pos==totalNodes(head)+1) nodeend(head,now);
	else if (pos>totalNodes(head)+1) printf("ERROR!! empty nodes before this position in the linkedlist");
	else nodebetween(head, now,pos);
}
void delStart(node * head)
{
	head=(*head).link;
}
void delEnd(node * head)
{
	int k=0,i=0;
	node * temp = head;
	while((*temp).link!=NULL) 
	{
		temp=(*temp).link;
		k++;
	}
	temp = head;
	while(i<k-1) 
	{
		temp=(*temp).link;
		i++;
	}
	(*temp).link = NULL;
}
void delBetween(node * head, int pos)
{
	int k=1;
	node * temp = head;
	while(k<pos-1) 
	{
		temp=(*temp).link;
		k++;
	}
	(*temp).link = NULL;
}
int deleteNode(node * head, int del)
{
	int flag =0;
	if((*head).link ==NULL)		
	{
		printf("EMPTY STACK\n");
		head=NULL;
		flag =1;
	}
	else if(del==1) delStart(head);
	else if(del==totalNodes(head)) delEnd(head);
	else if(del>totalNodes(head)) printf("ERROR!! no node is present at this position");
	else delBetween(head,del);
	return flag;
}
node * End(node * head)
{
	node * temp = head;
	while((*temp).link!=NULL) 
	{
		temp=(*temp).link;
		 
	}
	return temp;
}
void joint(node * head,int pos)
{
	node *temp = head;
	node * temp2=End( head);
	int i = 1;
	for(i=1;i<pos;i++)	temp =(*temp).link;	
	(*temp2).link =temp;
}

int loop(node * head)
{
	node * temp1, * temp2;
	temp1 =head;
	temp2 = head;
	int flag =0;
	temp1=(*temp1).link;
	temp2=(*temp2).link;
	if(temp2==NULL) return flag;
	temp2=(*temp2).link;
	while(1)
	{
		if(temp1==temp2) 
		{
			flag =1;
			break;
		}
		if(temp1==NULL||temp2==NULL) { flag =0 ;break;}
		temp1=(*temp1).link;
		temp2=(*temp2).link;
		if(temp2==NULL) break;
		temp2=(*temp2).link;
	}
	return flag;
}

int main()
{
	node*  head,*now;
	int nodeData,pos,del,flag,i,n=0,option;
	char c,dummy;
	 printf("Type the length of the link list");
	scanf("%d",&i);
		printf("type the data to create first node in the linked list:-\n");
		scanf("%d",&nodeData);n++;
		head = createnode(nodeData);

		while(n<i)
		{
				printf("put the data in the node:-\n");
				scanf("%d",&nodeData);
				now=createnode(nodeData);
				nodestart(&head, now);
				n++;
		}	
	 printLL( head);
	printf("If you want to join the linklist type 0 and if no type 1");
	scanf("%d",&option);
	if(option==0)
	{
		printf("Type the position of the node you want to join with");
		scanf("%d",&pos);
		joint(head,pos);
	}
	printf("press 1 to check the loop and 0 to not to check");
	scanf("%d",&option);
	if(option==1) 
	{
		flag =loop(head);
		if (flag ==1) printf("FOUND\n");
		else printf("NOT FOUND\n");
	}
	
return 0;
	
}
