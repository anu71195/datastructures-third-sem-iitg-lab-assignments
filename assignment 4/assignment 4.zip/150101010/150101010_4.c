//name - anurag ramteke
//roll no - 150101010
#include <stdio.h>
#include <stdlib.h>

void traverse(int rows,int columns,char**path,int b,int pos1,int pos2,int*flags,int*repeat)		//TRAVERSING BETWEEN ENTIRE AREA
{
	int count=0;
	if(path[pos1][pos2]=='L')
	{
		if(pos1<rows-1)if(path[pos1+1][pos2]=='B') count++;
		if(pos1>0)if(path[pos1-1][pos2]=='B') count++;
		if(pos2<columns-1)if(path[pos1][pos2+1]=='B') count++;
		if(pos2>0)if(path[pos1][pos2-1]=='B') count++;
	}
	if (count >=2) (*repeat)+=1;
	if(path[pos1][pos2]=='T'||path[pos1][pos2]=='B') {return;}							
	if(pos1==0||pos2==0||pos1==rows-1||pos2==columns-1) if(path[pos1][pos2]=='L')   {*flags =1;  return;}//DECLARATION OF FLAGS=1 TO KNOW THAT IT HAS REACHED THE END OF THE FOREST
	if(path[pos1][pos2]=='L')path[pos1][pos2]='B';
	if(pos1>0){traverse(rows,columns,path, b, pos1-1,pos2,  flags,repeat);}
	if(pos1<rows-1){traverse(rows,columns,path, b, pos1+1,pos2,  flags,repeat);}
	if(pos2>0){traverse(rows,columns,path, b, pos1,pos2-1,flags,repeat);}
        if(pos2<columns-1)
	 {traverse(rows,columns,path, b, pos1,pos2+1,  flags,repeat);}
	 
}
void inputANDoutput(int*rows,int*columns,char**path,int * n,int*b,int*pos1,int*pos2)		//FUNCTION WHICH GIVES INPUT AND OUTPUT AS WELL
{
	printf("Type the no of rows and columns:-");
	int i,j;
	scanf("%d %d",rows,columns);						
	if(*rows==0&&*columns==0) return;							//to end the function and then the loop
	path=(char**)malloc(sizeof(char*)*(*rows));
	for(  i =0;i<(*rows);i++) path[i]=(char*)malloc(sizeof(char)*(*columns));		//creating multidimentional array
	printf("Type the pattern:-\n");
	char dummy;
	scanf("%c",&dummy);
	for(i=0;i<(*rows);i++) 
	{
		for(  j=0;j<(*columns);j++)				//taking input of the area
				{
					scanf("%c",&path[i][j]);
					if(path[i][j]=='L') 
					{
						(*n)++;						//counting total no of lands
						if(i==0 ||j==0||i==(*rows-1)||j==(*columns-1)) 
						{
							(*b)++;					//counting total no of lands on boundary
							(*pos1)=i;				//position of the land on the boundary which is at last i andj i.e. for x and y coordinates
							(*pos2)=j;
						}
					}
				}
		scanf("%c",&dummy);
	}
	int flags=0;
	printf("b=%d ",*b);
	int repeat =0;
	if(*b==2) 									
	{
		//if(path[*pos1-1][*pos2]=='T'&&path[*pos1][*pos2+1]=='T') 
		//{
		//	printf("\nBad Luck\n");
		//		return;
		//}
		
		//if(pos1==0||pos2==0||pos1==rows-1||pos2==columns-1)
		//{
			path[*pos1][*pos2]='B';
			if(*pos1>0){traverse(*rows,*columns,path, *b, (*pos1)-1,*pos2, &flags,&repeat);}
			 if(*pos1<*rows-1){traverse(*rows,*columns,path, *b, (*pos1)+1,*pos2,  &flags,&repeat);}
			 if(*pos2>0){traverse(*rows,*columns,path, *b, *pos1,(*pos2)-1,&flags,&repeat);}
	        	 if(*pos2<*columns-1) {traverse(*rows,*columns,path, *b, *pos1,(*pos2)+1, &flags,&repeat);}
		//}
		//else traverse(*rows,*columns,path,*b,*pos1,*pos2,&flags);			//calling function to traverse the map

		if(flags==1&&repeat==0) printf("\nSubmitted!\n");
		else if (flags==1 &&repeat!=0) printf("\nBad Luck aS it has multiple routes\n");
		else printf("\nBad Luck\n");
		
	}
	else printf("\nBad Luck\n");
	
}


 
int main()
{
	int rows,columns,n=0,b=0,pos1,pos2;
	char**path;									//PATH IS THE DOUBLE ARRAY WITH COORDINATES AND THE TYPE OF AREA I.E. LAND OR TREE
	while(1)
	{
		inputANDoutput(&rows,&columns,path,&n,&b,&pos1,&pos2);			//FUNCTION WHICH GIVES INPUT AND OUTPUT AS WELL
		if(rows ==0 && columns ==0) break;					//DECLARATION TO END THE LOOP
		rows=columns=n=b=pos1=pos2=0;						//RESETTING ALL THE VALUES
		path =NULL;
	}
	
}

