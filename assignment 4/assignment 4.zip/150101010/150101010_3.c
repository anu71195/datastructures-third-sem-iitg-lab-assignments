name - anurag ramteke
roll no - 150101010
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
 
typedef struct node
{
	int row,column,value;				//row, column ,value are integers showing the index of the node and capital ROW AND COLUMN are the pointer to the NODE
	struct node *ROW,* COLUMN ;	
}NODE;
void printmatrix(NODE * HEAD,int rows,int columns)		//function to print the entire matrix
{
		NODE * TEMP; 
	 	if((*HEAD).column !=columns) printf("rows = %d and columns = %d and value =%d\t",(*HEAD).row,(*HEAD).column,(*HEAD).value);
	 	if((*HEAD).column<(columns)) printmatrix((*HEAD).COLUMN,rows,columns);
	 	else if ((*HEAD).column==columns &&(*HEAD).row ==rows) {return; }
	 	else { printmatrix((*((*HEAD).COLUMN)).ROW,rows,columns);}
}


void input(NODE*HEAD,int*rows,int*columns,int*non_zero)			//user input
{
	printf("Type the no of rows and columns in the matrix");
	scanf("%d%d",rows,columns);
	printf("\nType the no of non zero elements");
	scanf("%d",non_zero);
	(*HEAD).row=*rows;
	(*HEAD).column=*columns;
}
void add_node_column(NODE*HEAD,NODE * HEAD2,int n,int *i,int rows,int columns)	//add nodes to the column head and link it with the main head
{
	NODE * CHEAD;
	CHEAD =(NODE*) malloc(sizeof(NODE));
	(*CHEAD).column=*i;
	(*CHEAD).row = rows;
	(*i)++;									//io to count the no of columns in it
	(*CHEAD).ROW=NULL;
	(*CHEAD).COLUMN=NULL;
	(*HEAD).COLUMN =CHEAD;
	if (*i==n) 									//breaking condition
	{
		(*CHEAD).COLUMN = HEAD2;							//making a circular linked list in it
		return ;
	}
	add_node_column(CHEAD,HEAD2,n,i,rows,columns);
}	
void add_node_row(NODE*HEAD,NODE*HEAD2,int n, int *i,int rows, int columns)	//add nodes to the row head and link it with the main head
{
	NODE * CHEAD;
	CHEAD =(NODE*) malloc(sizeof(NODE));
	(*CHEAD).row=*i;							//i to count the no of rows in it
	(*CHEAD).column=columns;
	(*i)++;
	(*CHEAD).ROW=NULL;
	(*CHEAD).COLUMN=NULL;
	(*HEAD).ROW =CHEAD;
	if (*i==n) 									//breaking condition
	{
		(*CHEAD).ROW = HEAD2;							//making a circular linked list in it
		return ;
	}
	add_node_row(CHEAD,HEAD2,n,i,rows,columns);
}
void print_add_node_row(NODE * HEAD, NODE *HEAD2, int n, int * i)
{
	printf("column = %d\n",(*(*HEAD).COLUMN).column);
	(*i)++;
	if((*i)==2*n) return;
	print_add_node_row((*HEAD).COLUMN,HEAD2,n,i);
}
void crlink(NODE * HEAD,int rows, int columns,int non_zero)		//linking the head links of the column and rows with the main link which is at the center or intersection of the row and column link
{
	int i;
	i=0;
	add_node_row(HEAD,HEAD,rows,&i,rows,columns);
	i=0;
	add_node_column(HEAD,HEAD,columns,&i,rows,columns);
}
void Random_position(NODE* HEAD,int i, int j,int non_zero)	
{
	int ** temp,k,a,b,t;					
	temp = (int**)malloc(sizeof(int*)*i);
	for (k=0;k<i;k++) temp[k]=(int*)malloc(sizeof(int)*j);
	for(k=0;k<non_zero;k++)	
	{
		a=rand()%i;
		b=rand()%j;
		if(temp[a][b]==1) 
		{
			k--;
			continue;
		}
		else temp[a][b]=1;
	}
	for(k=0;k<i;k++) for(t=0;t<j;t++) 	if(temp[k][t]==1) temp[k][t]=rand()%100;
}
void matrix(NODE*HEAD,int value,int row, int column,NODE * HEAD2,int*i,int*max)//find the max and inserting nodes in the sparse matrix
{	 
	NODE * TEMP = HEAD,* TEMP2 ;
	while(1)
	{
		if((*TEMP).COLUMN==NULL) break;				//conditions for checking if the node is already present there or not and checking other condition of no node
		else if ((*TEMP).COLUMN==HEAD) break;
		else if((*((*TEMP).COLUMN)).column==column)
		{
		 	(*i)--;
		 	return;
		 }
		else TEMP=(*TEMP).COLUMN;
		
	}
	if(value>(*max)) *max = value;
	TEMP2=malloc(sizeof(NODE));
	(*TEMP2).row=row;
	(*TEMP2).column=column;
	(*TEMP2).value=value;

	TEMP = HEAD2;
	if((*HEAD2).ROW==NULL) 			//inserting node in sparse matrix in the column if the column is having no node already in it
	{
		(*HEAD2).ROW=TEMP2;
		(*TEMP2).ROW= HEAD2;
	}
	else					//inserting node in sparse matrix in the column if the column is having  node already in it
	{
		 while(1)
		 {
		 	if((*(*TEMP).ROW).row>row)
		 	{
		 		(*TEMP2).ROW=(*TEMP).ROW;
		 		(*TEMP).ROW = TEMP2;
		 		break;
		 	}
		 	else TEMP=(*TEMP).COLUMN;
		 }
	}
	TEMP = HEAD;	
	if((*TEMP).COLUMN ==NULL)	//inserting node in sparse matrix in the row if the row is having no node already in it
	{
		(*TEMP2).COLUMN = HEAD;
		(*HEAD).COLUMN = TEMP2;
		 
	}
	else			//inserting node in sparse matrix in the row if the row is having node already in it
	{
		 while(1)
		 {
		 	 
		 	if((*(*TEMP).COLUMN).column>column)
		 	{
		 		(*TEMP2).COLUMN=(*TEMP).COLUMN;
		 		(*TEMP).COLUMN = TEMP2; 
		 		break;
		 	}
		 	else 
		 	{
		 	TEMP=(*TEMP).COLUMN; 
		 	}
		 }
	}			
}

NODE* insert2(NODE*HEAD,int a, int b)//finding the main column node of the given generated column
{
 	NODE * TEMP;
	if((*HEAD).column==b) 
	{
		return HEAD ;
	}
	else TEMP = insert2((*HEAD).COLUMN,a,b);
	return TEMP;
}
void insert(NODE * HEAD,int a, int b ,NODE * HEAD2,int * i,int*max)//find the main row node of the given generated row and then insert it in the sparse matrix and then calculate max value
{
	NODE * TEMP;
	TEMP = HEAD;
	while(1)
	{
		if((*TEMP).row==a) 
		{
			matrix(TEMP,rand()%100,a,b,HEAD2,i,max); //find the max and inserting nodes in the sparse matrix
			break;
		}
		else TEMP = (*TEMP).ROW;
	}
	
}
void Random(NODE * HEAD, int non_zero,int rows, int columns,int*max)//randomly generate many value put it in the sparse matrix and then find the maximum value in the sparse matrix
{
	int a,b;
	NODE * HEAD2;
	int i=0;
	while(i<non_zero)						//looping for all the nonzero values in the sparse matrix
	{ 
		a=rand()%rows;						//randomly generating row and column position i.e.a  and b
		b=rand()%columns;				
		HEAD2 =insert2((*HEAD).COLUMN,a,b);			//finding the main column node of the given generated column
		insert((*HEAD).ROW,a,b,HEAD2,&i,max);			//find the main row node of the given generated row and then insert it in the sparse matrix and then calculate max value
		i++;
	}
}

int main()
{
	int rows,columns,non_zero,i,max=0;
	NODE * HEAD;
	input(HEAD,&rows,&columns,&non_zero);//calling function to take input
	crlink(HEAD,rows,columns,non_zero);//linking the head links of the column and rows with the main link which is at the center or intersection of the row and column link
	Random(HEAD,non_zero,rows,columns,&max);//randomly generate many value put it in the sparse matrix and then find the maximum value in the sparse matrix
	printf("maximum value is %d",max);	//prints max value
 
}
