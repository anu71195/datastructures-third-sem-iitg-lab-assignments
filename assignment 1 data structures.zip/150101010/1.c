#include <stdio.h> 
#include <stdlib.h>

void printArray(int * inputArray,int arrayLength)
{
	int i;
	for(i=0;i<arrayLength;i++)	printf("%d ",inputArray[i]);
}

void insertingKey(int * inputArray,int pos,int keyPosition )
{
	int i,key=inputArray[keyPosition],comparison=0;
	for( i=keyPosition-1;i>=pos;i--)	inputArray[i+1]=inputArray[i];		//shifts all the elements to the right so as to make space for the key at the pos
	inputArray[pos]=key;								//put the key in the array
}

int findPosition(int * inputArray,int keyPosition )
{
	int key,j;
	key=inputArray[keyPosition];
	j=keyPosition-1;
	while(j>=0&&key<inputArray[j])	j--;					//goes through the sorted part of the array to find the appropriate position of the key 
	j++;
	return j;
}

void sorting(int*inputArray,int arrayLength)
{
	int pos,i;	
	for( i=1;i<arrayLength;i++)						//loop starting with second element of the array to find its position  in the sorted part of that array
	{
		pos=findPosition(inputArray,i );				//returns the position where the key has to be inserted
		insertingKey(inputArray,pos,i );				//this function inserts the key at its proper position in the array.
	}	
}
 
void insertionSort(int arrayLength)						
{
		int * inputArray,i;
		inputArray = malloc(sizeof(int)*arrayLength);			//assigned memory to the pointer inputArray for storing elements from the user
		printf("Write those nos:-\n");					
		while(i<arrayLength)	scanf("%d",&inputArray[i++]);		//takes user input
		sorting(inputArray,arrayLength);				//sorts the input array
		printArray(inputArray,arrayLength); printf("\n");		//prints the sorted array
}

int main()											
{
	int  arrayLength;							//arrayLength=number of elements in the array;
	printf("Write how many nos to be sorted:-");
	scanf("%d",&arrayLength);					
	insertionSort(arrayLength);						
}
