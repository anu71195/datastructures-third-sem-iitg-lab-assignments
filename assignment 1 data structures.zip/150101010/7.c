#include <stdio.h>
#include <stdlib.h>

void printArray(int * inputArray,int arrayLength)
{
	int i;
	for(i=0;i<arrayLength;i++)	printf("%d ",inputArray[i]);
}
void randomGenerator(int * randomInput,int arrayLength)
{
	int i;
	for( i=0;i<arrayLength;i++)	randomInput[i]=rand()%100;	
}
void merging(int *randomInput,int first, int q, int last,int * inversions)
{
	int abc=last-first+1,i,j,k,*c;					//abc is the length of array which has to be made out of c
	c=malloc(sizeof(int)*abc);
	for(i=first;i<=last;i++)	c[i]=randomInput[i];
	c[i]='NULL';						
	i=first,j=q+1;
	for(k=first;k<=last;1)	
	{ 
		if (c[i]<=c[j]) 
			{
				randomInput[k++]=c[i++];
				if(i==q+1)	c[--i]='NULL';								
			}
		else 
		{
			randomInput[k++]=c[j++];   
			if(c[i]!='NULL') (*inversions)+=q-i+1; 
		}
	}
}
void mergeSort(int * randomInput,int first,int last,int arrayLength,int * inversions)	//sort the arrays bymergesort
{
	if(first<last)
	{
		int q = (first+last)/2;
		mergeSort(randomInput,first,q,arrayLength,inversions);
		mergeSort(randomInput,q+1,last,arrayLength,inversions);
		merging(randomInput,first,q,last,inversions);				//merges the elements and the sorted arrays into the final one
	}
 
}
int posByBinarySearch(int *inputArray, int keyPos,int first, int last)		// returns the position where the key has to be inserted
{
	int key,j,midElementPos;
	key = inputArray[keyPos];
	midElementPos=(first+last)/2;
	if(first==last) 
	{
		if(key>inputArray[first])		j=first+1;
		else j=first;
		return j;
	}
	else if(key<inputArray[midElementPos])	return posByBinarySearch(inputArray,keyPos,first,midElementPos);	 
	else	return posByBinarySearch(inputArray,keyPos,midElementPos+1,last);
}
void insertKey(int * inputArray,int pos,int keyPos)
{
	int i,key=inputArray[keyPos];
	for( i=keyPos-1;i>=pos;i--)		inputArray[i+1]=inputArray[i];
	inputArray[pos]=key;							
}
int binaryInsertionSort(int*randomInput,int arrayLength)
{
	int pos,i,inversions=0;  
	for(i=1;i<arrayLength;i++)
	{
		pos=posByBinarySearch(randomInput,i,0,i-1);			//returns position where the key has to be inserted
		inversions+=i-pos;						//no of inversions are the key position minus the position where it will be inserted
		insertKey(randomInput,pos,i);					//inserts key in its position
	}	
	return inversions;	 
}
int sorting(int*arrayA, int arrayLength)
{
	int inversions;
	if(arrayLength>=40)	mergeSort(arrayA,0,arrayLength-1,arrayLength,&inversions);	//if no of elements greater than 40then sort by mergesort else sort by binary insertionsort
	else	inversions=binaryInsertionSort(arrayA,arrayLength);
	return inversions; 
}

void numberOfInversions(int arrayLength)
{
	int*arrayA=malloc(sizeof(int)*arrayLength),inversions,option,i;
	printf("type 0 for randomGenerator and 1 for userinput:-");
	scanf("%d",&option);
	if(option==0)	randomGenerator(arrayA,arrayLength);
	else if (option==1) 	
	{
		printf("Enter the nos");		
		for( i=0;i<arrayLength;i++)	scanf("%d",&arrayA[i]);
	}
	printf("Original array:-\n");
	printArray(arrayA,arrayLength);printf("\n");		//prints the original array
	inversions=sorting(arrayA, arrayLength);		//returns the no of inversions 
	printf("Sorted array:-\n");				
	printArray(arrayA,arrayLength);printf("\n");		//prints sorted array
	printf("the no. of inversions in the sequences are:-%d",inversions);
}
int main()
{
	int  arrayLength;
	printf("Write how many nos to be sorted:-");
	scanf("%d",&arrayLength);
	numberOfInversions(arrayLength);//function to give the no of inversions
}
