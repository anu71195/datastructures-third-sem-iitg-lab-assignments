#include <stdio.h>
#include <stdlib.h>
void printarray(int * inputArray,int arrayLength)
{
	int i;
	for(i=0;i<arrayLength;i++)	printf("%d ",inputArray[i]);
}
void insertingKey(int * inputArray,int pos,int keyPosition )
{
	int i,key=inputArray[keyPosition];
	for( i=keyPosition-1;i>=pos;i--)	inputArray[i+1]=inputArray[i];	//shifts all the elements to the right so as to make space for the key at the pos
	inputArray[pos]=key;							//put the key in the array
}
int findPosition(int *inputArray, int keyPosition,int first, int last)
{
	int key,j,midElementPosition;
	key = inputArray[keyPosition];
	midElementPosition=(first+last)/2;					//position in the middle of the first and last element
	if(first==last) 							//if the first==last then it is the last element left in binary division
	{
		if(key>inputArray[first])		j=first+1;		//if that element is smaller than key then position after it is the position for the key
		else j=first;							//if that element is bigger than key then position before it is the position for the key		
		return j;							//returns the position for the key where it has to be inserted
	}
	else if(key<inputArray[midElementPosition])	return findPosition(inputArray,keyPosition,first,midElementPosition );	 //if key less than mid element then find position in the left of middle element
	else	return findPosition(inputArray,keyPosition,midElementPosition+1,last );						//else find it in the right of the middle element
}

void sorting(int*inputArray,int arrayLength)
{
	int i,pos;	
	for( i=1;i<arrayLength;i++)						//loop starting with second element of the array to find its position  in the sorted part of that array
	{
		pos=findPosition(inputArray,i,0,i-1);				//finds the appropriate position in the sorted array(left to it) where the key has to be inserted
		insertingKey(inputArray,pos,i);					//inserts the key in its proper positoin in the sorted array i.e. array at the left to it
	}	
}

void insertionSort(int arrayLength)
{
		int * inputArray,i;
		inputArray = malloc(sizeof(int)*arrayLength);		
		printf("Write those nos:-\n");
		while(i<arrayLength)	scanf("%d",&inputArray[i++]);		//takes user input
		sorting(inputArray,arrayLength);				//sorts the inputArray
		printarray(inputArray,arrayLength); printf("\n");		//prints the sorted array
}
int main()
{
	int  arrayLength;
	printf("Write how many nos to be sorted:-");
	scanf("%d",&arrayLength);
	insertionSort(arrayLength);					
}
