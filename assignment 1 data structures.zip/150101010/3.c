#include <stdio.h>
#include <stdlib.h>

void printarray(int * inputArray,int arrayLength)
{
	int i;
	for(i=0;i<arrayLength;i++)	printf("%d ",inputArray[i]);
}

void randomGenerator(int * randomInput,int arrayLength)			//fill the values in randomInput randomly
{
	int i;
	for( i=0;i<arrayLength;i++)	randomInput[i]=rand()%100;	
}

void insertKey(int * inputArray,int pos,int keyPosition,int*comparisons)
{
	int i,key=inputArray[keyPosition],comparison=0;
	for( i=keyPosition-1;i>=pos;i--)				//shifts all the elements to the right so as to make space for the key at the pos
	{
		inputArray[i+1]=inputArray[i];				
		comparison++;						//one comparison for every loop
	}
	comparison++;							//one comparison when the loop fails
	inputArray[pos]=key;						//put the key in the array
	*comparisons+=comparison;					//making the comparisons which is passed into the funcion equal to the total comparisons
}

int posByLinearSearch(int * inputArray,int keyPosition,int *comparison1)
{
	int key,j,comparison=0;
	key=inputArray[keyPosition];
	j=keyPosition-1;
	while(j>=0&&key<inputArray[j])				//goes through the sorted part of the array to find the appropriate position of the key 
	{
		j--;
		comparison+=2;;					//two comparisons of j and inputArray are made in every loop
	}
	comparison+=2;						//one time the condition fails then also two comparisons will be made at max
	*comparison1+=comparison;				//making the comparison1 which is passed into the funcion equal to the total comparisons
	j++;
	return j;
}

int posByBinarySearch(int *inputArray, int keyPosition,int first, int last,int*comparison2)
{
	int key,j,midElementPosition,comparison=0,temp;
	key = inputArray[keyPosition];
	midElementPosition=(first+last)/2;						//position in the middle of the first and last element				
	if(first==last) 								//if the first==last then it is the last element left in binary division
	{
		comparison++;								//every time if condition executes comparison increases by one
		if(key>inputArray[first])		j=first+1;			//if that element is smaller than key then position after it is the position for the key
		else j=first;								//if that element is bigger than key then position before it is the position for the key
		comparison++;								//every time this if and else statement executes one comparison is always made
		*comparison2+=comparison;						//making the comparison2 which is passed into the funcion equal to the total comparisons
		return j;								//returns the position for the key where it has to be inserted
	}
	else if(key<inputArray[midElementPosition])					//if key less than mid element then find position in the left of middle element
	{
		comparison+=2;								//if the first condition fails then second condition is checked and totla of two comparison will be made in the process
		*comparison2+=comparison;						//making the comparison2 which is passed into the funcion equal to the total comparisons
		return posByBinarySearch(inputArray,keyPosition,first,midElementPosition,comparison2);	 
	}
	else										//else if key is greater than or equal to mid element find it in the right of the middle element
	{
		comparison+=2;								//if the first condition fails then second condition is checked and totla of two comparison will be made in the process
		*comparison2+=comparison;						//making the comparison2 which is passed into the funcion equal to the total comparisons
		return posByBinarySearch(inputArray,keyPosition,midElementPosition+1,last,comparison2);
	}	
}


void insertionSort(int arrayLength)
{
		int pos,i,j,comparison1=0,comparison2=0,k; 
		printf("no of elements\t\tcomparisons\n                  linear search\t\t binary search\n");
		for( j=0;j<arrayLength;j++)								//user has put arrayLength = n then it will show comparison from the elements=1 till no of elements=n
		{
			int * randomInput = malloc(sizeof(int)*arrayLength);
			int * storeRandomInput=malloc(sizeof(int)*arrayLength);
			randomGenerator(randomInput,j+1);						//fill the values in randomInput for j+1 elements randomly
// 			printf("generated array:-");	printarray(randomInput,j+1);	printf("\n");	//remove comments from printf to see the generated array
			for(k=0;k<j+1;k++)	storeRandomInput[k]=randomInput[k]; 		 	//forms a dublicate of randomInput and named it storeRandomInput
			for( i=1;i<j+1;i++)								//loops through all the elements to make them key in the process
			{
				pos=posByLinearSearch(randomInput,i,&comparison1);			//find position by linear search where to put the key in the sorted part of array
				insertKey(randomInput,pos,i,&comparison1);				//inserting the key in its appropriate position
				comparison1++;								//each loop makes one comparison
			}
// 			printf("linear:-");	printarray(randomInput,j+1);	printf("\n");		//remove comments from printf to see the linearly sorted array
			comparison1++;									//every time the loop fails this comparison will be counted
			for(k=0;k<j+1;k++)	randomInput[k]=storeRandomInput[k];	 		//again makes the randomInput when it was generated randomly
			for(i=1;i<j+1;i++)								//loops through all the elements to make them key in the process
			{
				pos=posByBinarySearch(randomInput,i,0,i-1,&comparison2);		//find position by binary search where to put the key in the sorted part of array
				insertKey(randomInput,pos,i,&comparison2);				//inserting the key in its appropriate position
				comparison2++;								//each loop makes one comparison
			}	
			comparison2++;									//every time the loop fails this comparison will be counted
//		printf("Binary:-");	printarray(randomInput,j+1);	printf("\n");			//remove comments from printf to see the binary sorted array
			printf("%d\t\t\t  %d\t\t\t %d\n",j+1,comparison1,comparison2);
			comparison1=comparison2=0;							//makes comparisons =0
		}
}
int main()
{
	int  arrayLength;
	printf("Write the no of elements you want to calculate the comparisons of:-");
	scanf("%d",&arrayLength);								//arrayLength is the no of elements in the array 
	insertionSort(arrayLength);								
}
