#include<stdio.h>
#include<stdlib.h>
void printArray(int * inputArray,int arrayLength)
{
	int i;
	for(i=0;i<arrayLength;i++)	printf("%d ",inputArray[i]);
}
void randomGenerator(int * randomInput,int arrayLength,int k)
{
	int i;
	for( i=0;i<arrayLength;i++)	randomInput[i]=rand()%100;	//maximum value is set to 99
}
void merge(int *randomInput,int first, int q, int last)
{
	int abc=last-first+1,i,j,k,*c;				//abc is the size of the array which we have to make out of c where we are gong to put some values from randomInput 
	c=malloc(sizeof(int)*abc);
	for(i=first;i<=last;i++)	c[i]=randomInput[i];	
	c[i]='NULL';
	i=first,j=q+1;
	for(k=first;k<=last;1)	
	{
		if (c[i]<c[j]) 
			{
				randomInput[k++]=c[i++];
				if(i==q+1)	c[--i]='NULL';								
			}
		else randomInput[k++]=c[j++]; 
	}
}
void mergeSort(int * randomInput,int first,int last,int arrayLength)
{
	if(first<last)
	{

		int q = (first+last)/2;
		mergeSort(randomInput,first,q,arrayLength);
		mergeSort(randomInput,q+1,last,arrayLength);
		merge(randomInput,first,q,last);
	}
}
int posByBinarySearch(int *inputArray, int keyPos,int first, int last)
{


	int key,j,midElementPos;
	key = inputArray[keyPos];
	midElementPos=(first+last)/2;
	if(first==last) 
	{
		if(key>inputArray[first])		j=first+1;
		else j=first;
		return j;
	}
	else if(key<inputArray[midElementPos])	return posByBinarySearch(inputArray,keyPos,first,midElementPos);	 
	else		return posByBinarySearch(inputArray,keyPos,midElementPos+1,last);
	
	
	
}
void insertKey(int * inputArray,int pos,int keyPos)
{
	int i,key=inputArray[keyPos];
	for( i=keyPos-1;i>=pos;i--)		inputArray[i+1]=inputArray[i];
	inputArray[pos]=key;
}

void binaryInsertionSort(int*randomInput,int arrayLength)		
{
	int pos,i;  
	for(i=1;i<arrayLength;i++)
	{
		pos=posByBinarySearch(randomInput,i,0,i-1);	//returns position where the key has to be inserted
		insertKey(randomInput,pos,i);			//inserts the key in its proper position
	}	
}
void sorting(int*arrayA,int*arrayB,int arrayLength)
{
	if(arrayLength>=40)					//if arraylength is greater than 40 then merge sort otherwise binary sort to both the arrays
	{
		mergeSort(arrayA,0,arrayLength-1,arrayLength);	
		mergeSort(arrayB,0,arrayLength-1,arrayLength);
	}
	else	
	{
		binaryInsertionSort(arrayA,arrayLength);
		binaryInsertionSort(arrayB,arrayLength);
	}
}
int posBinarySearch(int *inputArray,int first, int last,int findNum)
{


	int  j,midElementPos, temp;
	midElementPos=(first+last)/2;
	if (findNum==inputArray[midElementPos])			return 1;//if found returns 1
	if(first==last) 								return 0;//if not found returns 0
	else if(findNum<inputArray[midElementPos])		return posBinarySearch(inputArray,first,midElementPos,findNum);	 		//if no wantd is less than midelement
	else							return posBinarySearch(inputArray,midElementPos+1,last,findNum);//if no wanted is more than midelement
		
}
void sumOfElementsIsM(int arrayLength)
{	int i,m,findNum,found=0,a,b,j,k=0,l=0,maxValue=100,option;
	int*arrayA=malloc(sizeof(int)*arrayLength);
	int*arrayB=malloc(sizeof(int)*arrayLength);
	printf("type 0 for randomGenerator and 1 for user input:-");
	scanf("%d",&option);
	if(option==0)
	{	
		randomGenerator(arrayA,arrayLength,maxValue);		//makes an array of randomelements
		randomGenerator(arrayB,arrayLength,maxValue);		//makes an array of randomelements
		printf("Original array:-\n");			
		printArray(arrayA,arrayLength);printf("\n");		//prints the generated array of arrayA
		printArray(arrayB,arrayLength);printf("\n");		//prints the generatedarray of arrayB
	}
	else if(option==1)	
	{
		printf("Give the input for the first array:-\n");
		for( i=0;i<arrayLength;i++)	scanf("%d",&arrayA[i]);		//userinput for array a
		printf("Give the input for the second array:-\n");		
		for( i=0;i<arrayLength;i++)	scanf("%d",&arrayB[i]);		//userinput for array b
	}
	sorting(arrayA,arrayB,arrayLength);					//sorts arraya and arrayb
	printf("Sorted array:-\n");
	printArray(arrayA,arrayLength);printf("\n");				//prints sorted arraya
	printArray(arrayB,arrayLength);printf("\n");				//prints sorted array
	printf("Write the m which is supposed to be the sum of a and b from arrayA and arrayB:-");
	scanf("%d",&m);
	for(i=0;i<arrayLength;i++)
	{
		if(m<arrayA[i]) break;	//loop through sorted array till it doesn't exceed m
		findNum=m-arrayA[i];	//no which we have to find in arrayb for some particular no from arraya
		found=posBinarySearch(arrayB,0,arrayLength,findNum);	//returns 1 if there is such no existss otheriwse 0
		if(found==1&&k==0) 
		{
			k++;
			printf("Found\n");printf("The numbers which are making the sum equal to %d are\n",m); 
			printf("number from arrayA \t number from arrayB\n");	
		}
		if(found==1)	
		{
			printf("%d\t\t\t%d\n",arrayA[i],findNum);
			l=1;
		}
		
	}
	
	 if(l==0)	printf("Not Found");
}
int main()
{
	int  arrayLength; 
	printf("Write how many nos you want in the sequence:-");
	scanf("%d",&arrayLength);
	sumOfElementsIsM(arrayLength);					//function to tell if the elements exist in two array who sum is making m which is given by them

}
