#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void printarray(int * inputArray,int arrayLength)
{
	int i;
	for(i=0;i<arrayLength;i++)	printf("%d ",inputArray[i]);
}

void randomgenerator(int * randomInput,int arrayLength)			//fill the values in randomInput randomly
{
	int i;
	for( i=0;i<arrayLength;i++)	randomInput[i]=rand()%100;	
}

void insertingKey(int * inputArray,int pos,int keyPosition,int*comparisons)
{
	int i,key=inputArray[keyPosition],comparison=0;
	for( i=keyPosition-1;i>=pos;i--)				//shifts all the elements to the right so as to make space for the key at the pos
	{
		inputArray[i+1]=inputArray[i];				
		comparison++;						//one comparison for every loop
	}
	comparison++;							//one comparison when the loop fails
	inputArray[pos]=key;						//put the key in the array
	*comparisons+=comparison;					//making the comparisons which is passed into the funcion equal to the total comparisons
}

int posByLinearSearch(int * inputArray,int keyPosition,int *comparison1)
{
	int key,j,comparison=0;
	key=inputArray[keyPosition];
	j=keyPosition-1;
	while(j>=0&&key<inputArray[j])				//goes through the sorted part of the array to find the appropriate position of the key 
	{
		j--;
		comparison+=2;;					//two comparisons of j and inputArray are made in every loop
	}
	comparison+=2;						//one time the condition fails then also two comparisons will be made at max
	*comparison1+=comparison;				//making the comparison1 which is passed into the funcion equal to the total comparisons
	j++;
	return j;
}

int posByBinarySearch(int *inputArray, int keyPosition,int first, int last,int*comparison2)
{
	int key,j,middleElementPosition,comparison=0,temp;
	key = inputArray[keyPosition];
	middleElementPosition=(first+last)/2;				//position in the middle of the first and last element
	if(first==last) 						//if the first==last then it is the last element left in binary division
	{
		comparison++;						//every time if condition executes comparison increases by one
		if(key>inputArray[first])		j=first+1;	//if that element is smaller than key then position after it is the position for the key
		else j=first;						//if that element is bigger than key then position before it is the position for the key
		comparison++;						//every time this if and else statement executes one comparison is always made
		*comparison2+=comparison;				//making the comparison2 which is passed into the funcion equal to the total comparisons
		return j;						//returns the position for the key where it has to be inserted
	}
	else if(key<inputArray[middleElementPosition])			//if key less than mid element then find position in the left of middle element
	{
		comparison+=2;						//if the first condition fails then second condition is checked and totla of two comparison will be made in the process
		*comparison2+=comparison;				//making the comparison2 which is passed into the funcion equal to the total comparisons
		return posByBinarySearch(inputArray,keyPosition,first,middleElementPosition,comparison2);	 
	}
	else								//else if key is greater than or equal to mid element find it in the right of the middle element
	{
		comparison+=2;						//if the first condition fails then second condition is checked and totla of two comparison will be made in the process
		*comparison2+=comparison;				//making the comparison2 which is passed into the funcion equal to the total comparisons
		return posByBinarySearch(inputArray,keyPosition,middleElementPosition+1,last,comparison2);
	}	
}
void merge(int *randomInput,int first, int q, int last,int*comparison)			//merges the elements from the end by two elements first and so on
{
	int abc=last-first+1,i,j,k,*c;
	c=malloc(sizeof(int)*abc);
	for(i=first;i<=last;i++)							//making a dublicate array named c of randomInput for some or all elements
	{
		c[i]=randomInput[i];
		(*comparison)++;					//one comparison for everyloop
	}
	(*comparison)++;						//comparison when loop fails
	c[i]='NULL';							//null because at the end of the c i.e after the last element will be zero and NULL will be far greater and zero willcreatesome problems
	i=first,j=q+1;
	for(k=first;k<=last;1)								//looping through all the elements in c
	{
		(*comparison)++;					//comparison for every loop
		if (c[i]<c[j]) 								//if the first element from the first half array is smaller than the other half then this happens 
			{
				randomInput[k++]=c[i++];
				if(i==q+1) c[--i]='NULL'; //after first half completes it will goto smallest element of next half whichdont want so we go the last element of the first half and then set it  NULL 
				(*comparison)++;		//comparison for every if statement
			}
		else randomInput[k++]=c[j++]; 	//else if the first element from the first half array is not smaller than the other half then this happens
		(*comparison)++;		//comparison for everytime if else statement executes
	}
	(*comparison)++;			//comparison for everytime for loop fails
}

void mergesort(int * randomInput,int first,int last,int arrayLength ,int * comparison)			//sorts an array by mergesort
{
	if(first<last)
	{

		int q = (first+last)/2;									//mid element 
		mergesort(randomInput,first,q,arrayLength,comparison);					//recursion of the function till it reaches some single element 
		mergesort(randomInput,q+1,last,arrayLength,comparison);					//recursion of the function till it reaches some single element 
		merge(randomInput,first,q,last,comparison);						//merges the elements from the end by two elements first and so on
	}
		(*comparison)++;									//everytime the if statement executes it will have one comparison
}

void sortingComparisons(int arrayLength)
{
		int pos,i,j,comparison1=0,comparison2=0,comparison3=0,k=0; 
		printf("no of elements\t\t\tcomparisons \n         	  linear search\t binary search\tmerge sort\n");
		for( j=0;j<arrayLength;j++)								//user has put arrayLength = n then it will show comparison from the elements=1 till no of elements=n
		{
			int * randomInput = malloc(sizeof(int)*arrayLength);		
			int * storeRandomInput=malloc(sizeof(int)*arrayLength);
			randomgenerator(randomInput,j+1);								//fill the values in randomInput for j+1 elements randomly
//			printf("generated array:-");	printarray(randomInput,j+1);	printf("\n");			//remove comments from printf to see the generated array
			for(k=0;k<j+1;k++)	storeRandomInput[k]=randomInput[k];	k=0;				//forms a dublicate of randomInput and named it storeRandomInput
			for( i=1;i<j+1;i++)										//loops through all the elements to make them key in the process
			{
				pos=posByLinearSearch(randomInput,i,&comparison1);					//find position by linear search where to put the key in the sorted part of array
				insertingKey(randomInput,pos,i,&comparison1);						//inserting the key in its appropriate position
				comparison1++;										//each loop makes one comparison
			}
//			printf("linear:-");	printarray(randomInput,j+1);	printf("\n");				//remove comments from printf to see the linearly sorted array
			comparison1++;											//every time the loop fails this comparison will be counted
			for(k=0;k<j+1;k++)	randomInput[k]=storeRandomInput[k];	k=0;				//again makes the randomInput when it was generated randomly
			for(i=1;i<j+1;i++)										//loops through all the elements to make them key in the process
			{
				pos=posByBinarySearch(randomInput,i,0,i-1,&comparison2);				//find position by binary search where to put the key in the sorted part of array
				insertingKey(randomInput,pos,i,&comparison2);						//inserting the key in its appropriate position
				comparison2++;										//each loop makes one comparison
			}	
			comparison2++;											//every time the loop fails this comparison will be counted
//			printf("Binary:-");	printarray(randomInput,j+1);	printf("\n");				//remove comments from printf to see the binary sorted array
			for(k=0;k<j+1;k++)	randomInput[k]=storeRandomInput[k];	k=0;				//again makes the randomInput when it was generated randomly
			mergesort(randomInput,0,j,j+1,&comparison3); 							//sorts an array by mergesort
//			printf("mergesort:-");	printarray(randomInput,j+1);	printf("\n");				//remove comments from printf to see the merge sorted array
 			printf("%d\t\t\t  %d\t        %d\t    %d\n",j+1,comparison1,comparison2,comparison3);
			if(comparison3<comparison2) 				break;					//if comparison3<comparison means threshold found then break the proces of counting
			comparison1=comparison2=comparison3=0;								//makes comparisons =0
		}

		printf("no of elements    linear search\t binary search\tmerge sort\n");
		if(comparison3<comparison2)	printf("Therefore the threshold where the merge sort's efficiency is better than binary insertion sort is at the element :- %d\n",j+1);//if thresholdfound then only
		else printf("Threshold is above the no. you typed. Please type a bigger no.\n");									//if threshold not found
}
int main()
{
	srand(time(NULL));
	int  arrayLength;
	printf("Write the no of elements you want to calculate the comparisons of:-");
	scanf("%d",&arrayLength);
	sortingComparisons(arrayLength);			//function which will sort to calculate threshold where the mergesort function better than binary insertion sort
}
