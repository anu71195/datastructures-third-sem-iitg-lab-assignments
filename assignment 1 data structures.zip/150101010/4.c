#include <stdio.h>
#include <stdlib.h>
void printarray(int * inputArray,int arrayLength)			//prints the array
{
	int i;
	for(i=0;i<arrayLength;i++)	printf("%d ",inputArray[i]);
}
void randomgenerator(int * randomInput,int arrayLength)			//fill the values in randomInput randomly
{
	int i;
	for( i=0;i<arrayLength;i++)	randomInput[i]=rand()%100;	
}
void merge(int *randomInput,int first, int q, int last)			//merges the elements from the end by two elements first and so on
{
	int abc=last-first+1,i,j,k,*c;
	c=malloc(sizeof(int)*abc);
	for(i=first;i<=last;i++)	c[i]=randomInput[i];		//making a dublicate array named c of randomInput for some or all elements
	c[i]='NULL';							//null because at the end of the c i.e after the last element will be zero and NULL will be far greater and zero willcreatesome problems
	i=first,j=q+1;
	for(k=first;k<=last;1)						//looping through all the elements in c
	{
		if (c[i]<c[j]) 						//if the first element from the first half array is smaller than the other half then this happens 
			{
				randomInput[k++]=c[i++];
				if(i==q+1)	c[--i]='NULL';		//after the first half completes it will go the smallest element of the next half which we dont want so we go the last element of the first 										half and then set it to NULL
			}
		else randomInput[k++]=c[j++]; 				//else if the first element from the first half array is not smaller than the other half then this happens
	}
}
void sorting(int * randomInput,int first,int last,int arrayLength )
{
	if(first<last)
	{
		int q = (first+last)/2;					//mid element 
		sorting(randomInput,first,q,arrayLength);		//recursion of the function till it reaches some single element 
		sorting(randomInput,q+1,last,arrayLength);		//recursion of the function till it reaches some single element
		merge(randomInput,first,q,last);			//merges the elements from the end by two elements first and so on
	}	
}
void mergeSort(int arrayLength)						//sorts an array by mergesort
{
		int * randomInput = malloc(sizeof(int)*arrayLength),option,i;
		printf("type 0 for randomgenerator and 1 for userinput:-");
		scanf("%d",&option);
		if(option==0)		
		{
			randomgenerator(randomInput,arrayLength);	//fill the values in randomInput randomly
			printf("Array generated:-	    ");
			printarray(randomInput,arrayLength);	printf("\n");	//prints generated array
		}
		else if(option==1)	for( i=0;i<arrayLength;i++)	scanf("%d",&randomInput[i]);	//takes input from user for the array
		sorting(randomInput,0,arrayLength-1,arrayLength);					//does the sorting by mergesort
		printf("Sorted array by merge sort:-");
		printarray(randomInput,arrayLength);							//prints the sorted array
		printf("\n");
}
int main()
{
	int  arrayLength ;
	printf("Write how many nos to be sorted:-");
	scanf("%d",&arrayLength);
	mergeSort(arrayLength);		
}
