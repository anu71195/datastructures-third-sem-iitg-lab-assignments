//NAME :- ANURAG RAMTEKE
//ROLL NO :- 150101010
#include <stdio.h>
#include <stdlib.h>
typedef struct node node;
//structure node
struct node
{
	node*parent;
	node*child;	//left most child
	node*sibling;
	int key;
	int degree;	
};
 
struct node* MAKE_bin_HEAP() //makes the binomial heap
{
	node*np;
	np=NULL;
	return np;
}
node * H = NULL;
node *Hr = NULL;
int bin_LINK(node* y,  node* z) //links y and z detaching y from the root list
{
	y->parent = z;
    y->sibling = z->child;
    z->child = y;
    z->degree = z->degree + 1;
}
node* CREATE_NODE(int k)//allocates space to some node first by making it
{
	node* p;//new node;
	p = (struct node*) malloc(sizeof(struct node));
	p->key = k;
	return p;
}
node* bin_HEAP_MERGE(struct node* H1, struct node* H2) //merges two trees h1 and h2
{
	node* H = MAKE_bin_HEAP();
	node* y;
	node* z;
	node* a;
	node* b;
	y=H1;
	z=H2;
	if (y != NULL)//checks the condition whether H1 or H2 one of them is NULL
	{
		if (z != NULL && y->degree <= z->degree) H = y;	//merging according to degree lower to higher of the trees
		else if (z != NULL && y->degree > z->degree) H = z;
		else H = y;
	}
	else
	{
		H = z;
	}
	while (y != NULL && z != NULL)//looping until one of H1 or H2 is NULL
	{
		if (y->degree < z->degree) y = y->sibling;//merging according to degree lower to higher of the trees
		else if (y->degree == z->degree)
		{
			a = y->sibling;

            y->sibling = z;

            y = a;
		}
		else
		{
			b = z->sibling;
			 z->sibling = y;
			 z = b;
		}
	}
	return H;
}
node* bin_HEAP_UNION(node* H1, node* H2)//union two heaps H1 and H2
{
	node* prev_x;
	node* next_x;
	node* x;
	node* H = MAKE_bin_HEAP();//makes a binomial heap
	H = bin_HEAP_MERGE(H1, H2);//merges heap H1 and H2
    if (H == NULL)  return H;
    prev_x = NULL;
    x = H;
    next_x = x->sibling;
    while (next_x != NULL) //loop the root list
    {
        if ((x->degree != next_x->degree) || (next_x->sibling != NULL)&& (next_x->sibling)->degree == (x->degree)) //case 1 and case 2
		{
            prev_x = x;
            x = next_x;
        }
        else 
        {
            if (x->key <= next_x->key)//case 3
            {

                x->sibling = next_x->sibling;

                bin_LINK(next_x, x);

            }
             else //case 4
             {

                if (prev_x == NULL)       H = next_x;

                else         prev_x->sibling = next_x;

                bin_LINK(x, next_x);

                x = next_x;

            }

        }

        next_x = x->sibling;

    }

    return H;


}
node* bin_HEAP_INSERT( node* H,  node* x)//inserts the node x with some new element in the heap H
{
	node* H1 = MAKE_bin_HEAP();//makes the binary heap
	x->parent = NULL;//initiating the values for the node which is going to be added
	x->child = NULL;
	x->sibling = NULL;
	x->degree = 0;
	H1 = x;
	H = bin_HEAP_UNION(H, H1);//unions the heap
	return H;
}
int REVERT_LIST(  node* y) //reverts the child list of the extracted min i.e. pointer starts from the right most child and the end one becomes left most child and the entire list is added to root list
{
	if (y->sibling != NULL)
	{
		REVERT_LIST(y->sibling);
        	(y->sibling)->sibling = y;
	}
	else Hr = y;
}
node* bin_HEAP_EXTRACT_MIN( node* H1)//extracts the minimum of the heap which will be in the root list
{
	 int min;
	   node* t = NULL;
	   node* x = H1;
	   node *Hr;
	   node* p;
	 Hr = NULL;
	       if (x == NULL) 
	       {
		       	return x;
	       }
	  p=x;
	  
	  
	 while (p->sibling != NULL)
	 {
	 	if ((p->sibling)->key < min)//if key is less than minimum than he minimum is updated and so on
	 	{
	 		min = (p->sibling)->key;
	 		t = p;
            x = p->sibling;
	 	}
	 	p = p->sibling;
	 }
     if (t == NULL && x->sibling == NULL) H1 = NULL;
     else if (t == NULL) H1 = x->sibling;
     else if (t->sibling == NULL)  t = NULL;
     else t->sibling = x->sibling;
     if (x->child != NULL) 
     {
     	REVERT_LIST(x->child);//reverts the child list of the extracted min i.e. pointer starts from the right most child and the end one becomes left most child and the entire list is added to root list
       (x->child)->sibling = NULL;//and the last element is pointed to NULL
     }
     H = bin_HEAP_UNION(H1, Hr);//union of H1 and Hr heaps
     return x;


}
void show_heap(node*head,int depth)//prints the heap in graphical form
{
	int i;
	if(head->sibling!=NULL)//if sibling of the head pointer is not null then show heap recursively and therefore prints the entire root list
	{
		show_heap(head->sibling,depth);
		if(head->sibling!=NULL && depth==0)
		{
			printf("\n");
		}
	}
	if(head->child!=NULL || head->parent==NULL)//whether the parent is null or head pointers child is not null then spacingwill be done and child will be printed in the graphical view
	{
		for(i=0;i<6*depth;i++)
		{
			printf(" ");
		}
		for(i=0;i<4;i++)
		{
			printf(" ");
		}
		printf("%d",head->key);
		if(head->child==NULL)
		{
			printf("\n");
		}
	}
	else
	{
		printf("    %d\n",head->key);//or else it will print the keay of the head pointer
	}
	if(head->child!=NULL)//if stillhead pointers child is not null then it will recurse again
	{
		show_heap(head->child,depth+1);
	}
}
int show_binomial_heap(node* head)//prints the heap in graphical form
{
	printf("\nstructure of binomial heap (rotated 90 degress):\n");//the graphical form will be rotated 90 degrees 
	if(head==NULL)//if heap is empty then this condition
	{
		printf("Heap is Empty\n");
		return 0;
	}
	else
	{
		show_heap(head,0);//otherwise it will show the heap
	}

}
char input(char*flag)
{
	char option;//option which will be taken by the user and wil be returned back
	while(1)
	{
		printf("\n");
		printf("MAKE-BINOMIAL-HEAP		:	c\n");//creates heap
		printf("BINOMIAL-HEAP-INSERT 		:	i\n");	//inserts an element
		printf("BINOMIAL-HEAP-EXTRACT-MIN	:	d\n");//extracts minimum element
		printf("Show binomial heap graphically 	:	s\n");//prints the graphical view of the heap
		printf("Turn off print after extract min:	+\n");//make the print extracted minimum funciton off
		printf("Turn on print after extract min	:	-\n");//make the print extracted minimum function on
		printf("to stop the program 		:	b\n");//breaks the program
		scanf("%c",&option);
		while(1)
		{
			if(option=='\n') scanf("%c",&option);//scans the input
			else break;
		}
		if(option=='+'||option=='-') //decides whether the extracted minimum has to be printed or not
		{
			if(*flag==option);
			{
				printf("\n");
				if(option=='+') printf("print is off\n");
				else if(option=='-') printf("print is on\n");
			}
			*flag=option;
			printf("\n");
		}
		else break;
	}
	printf("\n");
	return option;
}
int main()
{
	int type_of_input,t=1,in,optional,x;	;//optinoal whether to print the extracted min or not by taking input + and - and type of input is for file input or user input
	char option,flag='-',abc;//option is the character to manipulate optinal and flag does the same thing
	node*head;
	node* np;
	node *p;
	char ch;
	FILE * fp;//file pointer
	fp=fopen("binomialHeapTest.txt","r");//opens the file
	printf("0/1	: userinput/fileinput: ");
	scanf("%d",&type_of_input);
	printf("\n\n");
	while(1)
	{
		if(type_of_input==1)
		{
			while(1)
			{
				if(feof(fp)) break;//breaking condition of the loop
				fscanf(fp,"%c",&option);
				if(option=='#')
				{//these lines of code ignore the commented lines in the file
					while(1) 
					{
						fscanf(fp,"%c",&option);
						if(option=='-') optional=1;
						else if (option=='+') optional=0;
						if(option=='\n') break;
					}
					fscanf(fp,"%c",&option);
					if(option=='-') optional=1;//manipulates the optional by option
					else if (option=='+') optional=0;
				}
				if(option=='c'||option=='C'||option=='s'||option=='S'||option=='i'||option=='I'||option=='d'||option=='D')	//input for create, insert, extract,print
				{
				
					if(option=='c'||option=='C') H=NULL;//creates heap
					else if(option=='s'||option=='S')
					{
						show_binomial_heap(H);//prints the heap
					}		
					else if(option=='i'||option=='I')
					{
						

						fscanf(fp,"%d",&in);
						 np = CREATE_NODE(in);//creates a node
						H = bin_HEAP_INSERT(H, np);//inserts the key in heap
					}
					else if (option=='d'||option=='D')
					{
						p = bin_HEAP_EXTRACT_MIN(H);
		                if (p != NULL)if(optional==1)printf("\nTHE EXTRACTED NODE IS %d", p->key);//prints extracted node if the input is - i.e. optional =1
					}
				}
			}
		}
		else if(type_of_input==0)
		{
		while(1)
		{
			option=input(&flag);
			if(flag=='-') optional=1;//manipulates the optional by flag
			else optional =0;
			if(option=='b') break;//break input
			else if(option=='c')//input to create heap
			{
				H=NULL;
			}
			else if(option=='i')//input to insert an element in the heap
			{
				printf("give the value:");
				scanf("%d",&x);
				np = CREATE_NODE(x);//creates the node
				H = bin_HEAP_INSERT(H, np);//inserts the node in the heap
			}
			else if(option=='d')//extracts the minimum element
			{
				 p = bin_HEAP_EXTRACT_MIN(H);//extracts the minimum element
		         if (p != NULL)if(optional==1)printf("\nTHE EXTRACTED NODE IS %d", p->key);//prints the element if optional =1 i.e. flag=-
			}
			else if(option=='s')
			{
				show_binomial_heap(H);//prints the binomial heap
			}
			else printf("WRONG INPUT\n");
		}
		
		}break;
	}
	printf("\n");
}
