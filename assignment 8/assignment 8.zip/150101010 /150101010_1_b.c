//NAME :- ANURAG RAMTEKE
//ROLL NO :- 150101010
//making heap using all the elements at a time
#include <stdio.h>
#include <stdlib.h>
void swap(int*array, int p, int i)
//swaps p and i in the arraray array
{
	int temp;
	temp=array[p] ;
	array[p]=array[i];
	array[i]=temp;
}
void heapify (int *array, int i, int heapsize)
//heapify the array with the last element no i and heapsize as heapsize
{
    int left = 2*i     ;              //left child
    int right = 2*i +1;           //right child
    int smallest;
    if(left<= heapsize && array[left] < array[i] ) smallest = left;
    else
         smallest = i;
    if(right <= heapsize && array[right] < array[smallest] )
        smallest = right;
    if(smallest != i )
    {
        swap (array,i ,smallest);
        heapify (array, smallest,heapsize);
    } 
 }
 void heapify_2(int * array, int i,int heapsize)
 //heapify the array with the last element no i and heapsize as heapsize
{
	int left, right,direction;//direction chooses between left and right
	left =2*i;
	right = 2*i+1;
	if(i>((heapsize/2))) return;
	if(array[left]<array[right]) direction=left;
	else direction=right;
	if(heapsize==i&&heapsize%2==0) direction==left;
	if(array[direction]<array[i]) swap(array,direction,i);
	else return;
	heapify_2(array,direction,heapsize);
}
int extract_min(int * array,int*heapsize)
//extracts the minimum element
{
	int min = array[1];
	array[1]=array[*heapsize];
	heapify_2(array,1,*heapsize);	
	(*heapsize)--;
	return min;
}
 
 void make_heap (int *array,int heapsize)
 //creates the heap of all the elements
{
	int i,flag=2;
	for(i = heapsize/2 ; i >= 1 ; i-- )
    	{
        	heapify (array, i,heapsize) ;
    	}
    //	printf("flag is%d",flag);
}
int main()
{
	int n,*array,i=0,k,heapsize,j,min;//array which will form heap and n is the no of elements with i is counter and min is the minimum element
	FILE * input;//declaring file object
	input=fopen("test.dat.txt","r");//file input
	fscanf(input,"%d",&n);
	array=(int*)malloc(sizeof(int)*(n+1));
	for(i=1;i<=n;i++)
	{
		fscanf(input,"%d",&array[i]);

	}
	heapsize=i-1;
	make_heap(array,heapsize);
	printf("Write the value of k:");
	scanf("%d",&k);
	for(i=0;i<k;i++)
	{
		min=extract_min(array,&heapsize)	;
		printf("%d\n",min);
	}
	//for(i=1;i<=n;i++)
	//{
	//	printf("%d\n",array[i]);
	//}
	
}
