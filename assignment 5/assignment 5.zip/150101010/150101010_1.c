//NAME :- ANURAG RAMTEKE
//ROLL NO :150101010
#include <stdio.h>
#include <stdlib.h>
//edges start from index=1
void linkage(int**link,int u, int v,int*ui )	//to create adjacency list
{
	link[u][ui[u]++]=v;
	link[v][ui[v]++]=u;
}
void input(int * n, int *e,int***link,int**parent,int**color,int**ui )	//to take input
{
	int u,i,v;
	char dummy;
	printf("Type the no of vertices=");
	scanf("%d",n);	
	printf("Type the no of edges=");
	scanf("%d",e);
	*parent = (int*)malloc(sizeof(int)*(*(n+1)));		
	*color = (int*)malloc(sizeof(int)*(*(n+1)));
	for(i=0;i<(*n);i++) (*parent)[i+1]=(*color)[i+1]=0;
	(*ui) = (int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++)					//ui is the counter on no of elements in adjacency list corresponding to every node
	{
		(*ui)[i+1]=1;
	}
	*link = (int**)malloc(sizeof(int*)*((*n)+1));		//stores adjacency list
	for(i=0;i<(*n);i++) (*link)[i+1]=(int*)malloc(sizeof(int)*((*n)+1));
	printf("Give the edges\n");
	for(i=0;i<(*e);i++)
	{

		scanf("%d",&u);
		//scanf("%c",&dummy);	
		scanf("%d",&v);
		linkage(*link,u,v,*ui);				//to create adjacency list
	}
}
void print_cycle(int u,int v,int **link,int*parent)
{
	if(u==v) printf("%d ",u);
	else 
	{
		print_cycle(u,parent[v],link,parent);
		printf("%d ",v);
	}
}
void DFS_visit(int i,int**link,int*ui,int*color,int*parent,int*cycles,int*connect,int*ncon)
{
	if(i>0) connect[(*ncon)++]=i; 			//storing connected components
	int j;
	color[i]=1;
	for(j=0;j<ui[i];j++)	
	{
		if(color[link[i][j+1]]==0)
		{
		 	parent[link[i][j+1]]=i;
			DFS_visit(link[i][j+1],link,ui,color,parent,cycles,connect,ncon);
		}
		else if(color[link[i][j+1]]==1)
		{
			if(parent[link[i][j+1]]==i||parent[i]==link[i][j+1]) continue;
			else 
			{
				(*cycles)++;
				if(*cycles==1) printf("Cycle found\n");
				printf("cycle no. %d:-",*cycles);
				print_cycle(link[i][j+1],i,link,parent);		//cycles printing
				printf("\n");	
			}			
		}
	}
	color[i]=2;
}

void DFS(int ** link,int*parent,int*color,int n, int e,int*ui ,int*cycles,int*connect,int*ncon)
{
	int i=0,j=0,k,t=1;
	for(i=0;i<n;i++)	
	{
		if(color[i+1]==0) 
		{
			DFS_visit(i+1,link,ui,color,parent,cycles,connect,ncon);	//ui is the counter on no of elements in adjacency list corresponding to every node
			printf("\nconnected  components %d=  ",t++);			//ncon is the no of connected elements in connected set of vertices
			for(k=0;k<*ncon;k++) printf("%d  ",connect[k]);			//prints connected components
			printf("\n");
			*ncon=0;
		}
	}
}
int main()
{
	int n,e,**link,*parent,*color,*ui,*vi,cycles=0,*connect,ncon=0;// n = no of nodes; e = no of edges; link is adjacecy list; 
	input(&n,&e,&link,&parent,&color,&ui );				//function to take input
	connect = (int*)malloc(sizeof(int)*n);
	DFS(link,parent,color,n,e,ui,&cycles,connect,&ncon);		
	if(cycles==0) printf("\nNO CYCLE FOUND\n");
}
