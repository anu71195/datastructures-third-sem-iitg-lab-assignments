//NAME :- ANURAG RAMTEKE
//ROLL NO :150101010
#include <stdio.h>
#include <stdlib.h>
void linkage(int**link,int u, int v,int*ui )		//to create adjacency list
{
	link[u][ui[u]++]=v;
}
void input(int * n, int *e,int***link,int**parent,int**color,int**ui,int***edge,int**arrival,int**departure )//to take input
{
	int u,i,v,j;
	char dummy;
	printf("Type the no of vertices=");
	scanf("%d",n);	
	printf("Type the no of edges=");
	scanf("%d",e);
	*parent = (int*)malloc(sizeof(int)*(*(n+1)));
	*color = (int*)malloc(sizeof(int)*(*(n+1)));
	*arrival= (int*)malloc(sizeof(int)*(*(n+1)));
	*departure= (int*)malloc(sizeof(int)*(*(n+1)));
	for(i=0;i<(*n);i++) (*parent)[i+1]=(*color)[i+1]=(*arrival)[i+1]=(*departure)[i+1]=0;
	(*ui) = (int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++)
	{
		(*ui)[i+1]=1;		//ui is the counter on no of elements in adjacency list corresponding to every node
	}
	*link = (int**)malloc(sizeof(int*)*((*n)+1));	//stores adjacency list
	*edge =(int**)malloc(sizeof(int*)*((*n)+1));
	for(i=0;i<(*n);i++) (*link)[i+1]=(int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++) (*edge)[i+1]=(int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++)	for(j=0;j<(*n);j++) (*edge)[i+1][j+1]=0;
	printf("Give the edges\n");
	for(i=0;i<(*e);i++)
	{
		scanf("%d",&u);
		//scanf("%c",&dummy);	
		scanf("%d",&v);
		linkage(*link,u,v,*ui);		//to create adjacency list
	}
}
void print_cycle(int u,int v,int **link,int*parent)
{
	if(u==v) printf("%d ",u);
	else 
	{
		print_cycle(u,parent[v],link,parent);
		printf("%d ",v);
	}
}
void DFS_visit(int i,int**link,int*ui,int*color,int*parent,int*cycles,int*connect,int*ncon,int**edge,int*arrival,int*departure,int*adi)
{
	if(i>0) connect[(*ncon)++]=i; 		//storing connected components
	int j;
	color[i]=1;
	arrival[i]=(*adi)++;
	for(j=0;j<ui[i];j++)	
	{
		if(color[link[i][j+1]]==0)
		{
			edge[i][link[i][j+1]]=1;			//edge if 1 then tree edge
		 	parent[link[i][j+1]]=i;
			DFS_visit(link[i][j+1],link,ui,color,parent,cycles,connect,ncon,edge,arrival,departure,adi);
		}
		else if(color[link[i][j+1]]==1)
		{
			edge[i][link[i][j+1]]=2;			//edge if 2 then back edge
			if(parent[link[i][j+1]]==i||parent[i]==link[i][j+1]) continue;
			else 
			{
				(*cycles)++;
			//	if(*cycles==1) printf("Cycle found\n");
			//	printf("cycle no. %d:-",*cycles);
			//	print_cycle(link[i][j+1],i,link,parent);//cycles printing
			//	printf("\n");	
			}			
		}
		else if(color[link[i][j+1]]==2)
		{
			if(/*departure[i]>departure[link[i][j+1]]&&*/arrival[i]<arrival[link[i][j+1]])	edge[i][link[i][j+1]]=3;	//edge if 3 then forward edge
			if(arrival[i]>departure[link[i][j+1]]) edge[i][link[i][j+1]]=4;							//edge if  4 then crossedge
		}
	}

	departure[i]=(*adi)++;
	color[i]=2;				
}
void print_cond(int**edge,int**link,int i,int j)		//conditions for the edges put
{
	if(edge[i+1][link[i+1][j]]==1) printf("Tree edge\n"); 
	else if(edge[i+1][link[i+1][j]]==2) printf("Back edge\n");
	else if(edge[i+1][link[i+1][j]]==3) printf("Forward edge\n");
	else if(edge[i+1][link[i+1][j]]==4) printf("cross edge\n");
}
void print_edges(int**edge,int**link,int*ui,int n)
{
	int i,j;
	printf("\n");
	for(i=0;i<n;i++)	for(j=1;j<ui[i+1];j++)	
				{
					printf("%d-->%d is ",i+1,link[i+1][j]);
					print_cond(edge,link,i,j);			//prints the type of edges with the conditions in whcih the edge is in
				}
}
void DFS(int ** link,int*parent,int*color,int n, int e,int*ui ,int*cycles,int*connect,int*ncon,int**edge,int*arrival,int*departure,int*adi)
{
	int i=0,j=0,k,t=1;
	for(i=0;i<n;i++)	
	{
		if(color[i+1]==0) 
		{
			DFS_visit(i+1,link,ui,color,parent,cycles,connect,ncon,edge,arrival,departure,adi);//ui is the counter on no of elements in adjacency list corresponding to every node
			//printf("\nconnected  components %d=  ",t++);				//ncon is the no of connected elements in connected set of vertices
			//for(k=0;k<*ncon;k++) printf("%d  ",connect[k]);		//prints connected components
			//printf("\n");
			*ncon=0;
		}
	}
	print_edges(edge,link,ui,n);					//print the type of edges present in the graph
}
int main()
{
	int n,e,**link,*parent,*color,*ui,*vi,cycles=0,*connect,ncon=0,**edge,*arrival,*departure,adi=0;// n = no of nodes; e = no of edges; link is adjacecy list; edge stores the type of edge;adi is arrival and departure index
	input(&n,&e,&link,&parent,&color,&ui,&edge,&arrival,&departure );			//function to take input
	connect = (int*)malloc(sizeof(int)*n);
	DFS(link,parent,color,n,e,ui,&cycles,connect,&ncon,edge,arrival,departure,&adi);	
	//if(cycles==0) printf("\nNO CYCLE FOUND\n");
}
