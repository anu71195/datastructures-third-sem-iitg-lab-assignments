//NAME :- ANURAG RAMTEKE
//ROLL NO :150101010
#include <stdio.h>
#include <stdlib.h>
void linkage(int**link,int u, int v,int*ui,int**path )//to create adjacency list
{
	link[u][ui[u]++]=v;
	path[u][v]=1;
}
void input(int * n, int *e,int***link,int**parent,int**color,int**ui ,int***path)//to take input
{
	int u,i,v,j;
	char dummy;
	printf("Type the no of vertices=");
	scanf("%d",n);	
	printf("Type the no of edges=");
	scanf("%d",e);
	*parent = (int*)malloc(sizeof(int)*(*(n+1)));
	*color = (int*)malloc(sizeof(int)*(*(n+1)));
	for(i=0;i<(*n);i++) (*parent)[i+1]=(*color)[i+1]=0;
	(*ui) = (int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++)		(*ui)[i+1]=1;			//ui is the counter on no of elements in adjacency list corresponding to every node
	*path=(int**)malloc(sizeof(int*)*((*n)+1));
	*link = (int**)malloc(sizeof(int*)*((*n)+1));		//stores adjacency list
	for(i=0;i<(*n);i++) (*link)[i+1]=(int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++) (*path)[i+1]=(int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++)	for(j=0;j<(*n);j++) (*path)[i+1][j+1]=0;
	printf("Give the edges\n");
	for(i=0;i<(*e);i++)
	{

		scanf("%d",&u);
		//scanf("%c",&dummy);	
		scanf("%d",&v);
		linkage(*link,u,v,*ui,*path);		//to create adjacency list
	}
}
void print_cycle(int u,int v,int **link,int*parent,int**path)
{
	if(u==v) path[v][v]=1; 
	else 
	{
		print_cycle(u,parent[v],link,parent,path);		//checks if the path is connected back to itself or not,if not connected then n,n element in the matrix is zero
		path[v][v]=1;
	}
}
void DFS_visit(int i,int**link,int*ui,int*color,int*parent,int*cycles,int*connect,int*ncon,int**path)
{
	if(i>0) connect[(*ncon)++]=i; 			//storing connected components
	int j;
	color[i]=1;
	for(j=0;j<ui[i];j++)	
	{
		if(color[link[i][j+1]]==0)
		{
		 	parent[link[i][j+1]]=i;
			DFS_visit(link[i][j+1],link,ui,color,parent,cycles,connect,ncon,path);
		}
		else if(color[link[i][j+1]]==1)
		{
			if(parent[link[i][j+1]]==i||parent[i]==link[i][j+1]) continue;
			else 
			{
				(*cycles)++;
				print_cycle(link[i][j+1],i,link,parent,path);
			}			
		}
	}
	color[i]=2;
}
void color_zero (int*color,int n)			//makes all the color of nodes =0
{
	int i;
	for(i=0;i<n;i++) color[i+1]=0;
}
void print_matrix(int**path,int n)			//prints final matrix i.e. output of path whether connected or not 
{
	int i,j;
	printf(" |");
	for(i=0;i<n;i++) printf("%d  ",i+1);  
	printf("\n");
	printf("-+");
	for(i=0;i<n;i++) printf("---");
	printf("\n");
	for(i=0;i<n;i++)	
	{
		printf("%d|",i+1);
		for(j=0;j<n;j++) printf("%d  ",path[i+1][j+1]);
		printf("\n");
	}
}
void DFS(int ** link,int*parent,int*color,int n, int e,int*ui ,int*cycles,int*connect,int*ncon,int**path)
{
	int i=0,j=0,k,t=1;
	for(i=0;i<n;i++)	
	{
		if(color[i+1]==0) 

		{
			DFS_visit(i+1,link,ui,color,parent,cycles,connect,ncon,path);	//ui is the counter on no of elements in adjacency list corresponding to every node////ncon is the no of connected elements in connected set of vertices
			color_zero(color,n); 						//makes all the color of nodes =0	
			for(k=1;k<*ncon;k++) path[connect[0]][connect[k]]=1; 		//path is present then equating to 1
			*ncon=0;
		}
	}
	print_matrix(path,n);
}
int main()
{
	int n,e,**link,*parent,*color,*ui,*vi,cycles=0,*connect,ncon=0,**path;// n = no of nodes; e = no of edges; link is adjacecy list; path pointer to store whether two nodes have path or not
	input(&n,&e,&link,&parent,&color,&ui,&path );//function to take input
	connect = (int*)malloc(sizeof(int)*n);
	DFS(link,parent,color,n,e,ui,&cycles,connect,&ncon,path);	 
}
