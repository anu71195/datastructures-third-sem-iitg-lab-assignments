//NAME :- ANURAG RAMTEKE
//ROLL NO :150101010
#include <stdio.h>
#include <stdlib.h>
//edges start from index=1
void linkage(int**link,int u, int v,int*ui,int *end ,int *start,int i)	//to create adjacency list
{
	end[i]=v;
	start[i]=u;
	link[u][ui[u]++]=v;
}
void input(int * n, int *e,int***link,int**parent,int**color,int**ui,int***linkt,int**uit,int**finish,int**traversal,int***edge ,int**start,int**end,int**group,int***final,int**index)	//to take input
//takes input from the user and also allocates spaces to the pointer
{
	int u,i,v,j;
	char dummy;
	printf("Type the no of vertices=");
	scanf("%d",n);	
	printf("Type the no of edges=");
	scanf("%d",e);
	int k =*n;
	k=2*k;
	*parent = (int*)malloc(sizeof(int)*(*(n)+1));
	*index=(int*)malloc(sizeof(int)*(*(n)+1));
	*start= (int*)malloc(sizeof(int)*(*(e)+1));
	*end= (int*)malloc(sizeof(int)*(*(e)+1));
	*group=(int*)malloc(sizeof(int)*(*(n)+1));	
	*traversal=	(int*)malloc(sizeof(int)*(*(n)+1));
	*color = (int*)malloc(sizeof(int)*(*(n)+1));
	*finish= (int*)malloc(sizeof(int)*(k)+2);
	for(i=0;i<(*n);i++) (*parent)[i+1]=(*color)[i+1]=0;
	(*ui) = (int*)malloc(sizeof(int)*((*n)+1));
	(*uit) = (int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++)					//ui is the counter on no of elements in adjacency list corresponding to every node
	{
		(*ui)[i+1]=1;
		(*index)[i+1]=1;
		(*uit)[i+1]=1;
	}
	*linkt=(int**)malloc(sizeof(int*)*((*n)+1));
	*final=(int**)malloc(sizeof(int*)*((*n)+1));
	*edge=(int**)malloc(sizeof(int*)*((*n)+1));
	*link = (int**)malloc(sizeof(int*)*((*n)+1));		//stores adjacency list
	for(i=0;i<(*n);i++) (*edge)[i+1]=(int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++) (*final)[i+1]=(int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++) (*linkt)[i+1]=(int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++) (*link)[i+1]=(int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++) for(j=0;j<(*n);j++) (*edge)[i+1][j+1]=0;
	for(i=0;i<(*n);i++) for(j=0;j<(*n);j++) (*final)[i+1][j+1]=0;
	printf("Give the edges\n");
	for(i=0;i<(*e);i++)
	{ 

		scanf("%d%d",&u,&v);

		linkage(*link,u,v,*ui,*end,*start,i);	//to create adjacency list

	}		//printf("%d %d ",*start[0],*end[0]);
	printf("\n\n");
}
void print_cycle(int u,int v,int **link,int*parent)
//prints cycles in the graph
{
	if(u==v)  printf("%d ",u);
	else 
	{
		print_cycle(u,parent[v],link,parent);
		printf("%d ",v);
	}
}
void DFS_visit(int i,int**link,int*ui,int*color,int*parent,int*cycles,int*connect,int*ncon,int flag,int*finish,int *clock,int*traversal,int*tt,int*lt,int**edge)
//traverses the graph by DFS method 
{
	if(i>0) connect[(*ncon)++]=i; 			//storing connected components
	else if (flag==1) 
	{
				traversal[(*lt)]=i;
				(*lt)++;
	}
	int j;
	color[i]=1;
	for(j=0;j<ui[i];j++)	
	{
		if(color[link[i][j+1]]==0)
		{
		 	parent[link[i][j+1]]=i;
			DFS_visit(link[i][j+1],link,ui,color,parent,cycles,connect,ncon,flag,finish,clock,traversal,tt,lt,edge);
		}
		else if(color[link[i][j+1]]==1)
		{
			if(parent[link[i][j+1]]==i||parent[i]==link[i][j+1]) continue;
			else 
			{
				(*cycles)++;
			}			
		}
	}
	color[i]=2;
	if(flag ==0)finish[(*clock)++]=i;
}

void DFS(int ** link,int*parent,int*color,int n, int e,int*ui ,int*cycles,int*connect,int*ncon,int flag,int*finish,int*clock,int *traversal,int*tt,int**edge,int*group,int*ncc)
{
	int i=0,j=0,k,t=1,lt=0,**temp;
	
if(flag==0)	for(i=0;i<n;i++)	
	{
		if(color[i+1]==0) 
		{
			DFS_visit(i+1,link,ui,color,parent,cycles,connect,ncon,flag,finish,clock,traversal,tt,&lt,temp);	//ui is the counter on no of elements in adjacency list corresponding to every node
			t++;	
			*ncon=0;
		}
	}
else if(flag==1)	{ while((*clock)>0)	
	{ 
		i=finish[*clock-1];
		if(color[i]==0) 
		{
			DFS_visit(i,link,ui,color,parent,cycles,connect,ncon,flag,finish,clock,traversal,tt,&lt,edge);	//ui is the counter on no of elements in adjacency list corresponding to every node
			if(flag==1) printf("\nStrongly connected  components %d=  ",t);			//ncon is the no of connected elements in connected set of vertices
			t++;	
			if(flag==1) for(k=0;k<*ncon;k++) 
				    {
						printf("%d  ",connect[k]);			//prints connected components
						group[connect[k]]=t-1;
						
				    }
			if(flag ==1) printf("\n");
			*ncon=0;
		}
		(*clock)--;
	}}
	*ncc=t;
}

void graph_transpose(int ** link,int**linkt,int n,int *ui,int*uit)
//creates another adjacency list called linkt which stores the transpose of original adjacency list link
{
		int i,j;
		for(i=1;i<=n;i++) for(j=1;j<ui[i];j++) linkt[link[i][j]][uit[link[i][j]]++] 	=i;
}
void color_zero(int*color,int n)
//makes all the node colors =0
{
	int i;
	for(i=0;i<n;i++) color[i+1]=0;
}
void component(int**edge,int*group,int*start,int*end,int**final,int n, int e,int *index,int ncc)
//creates a component graph of the given graph
{
	int i,j,temp;
	for (i=0;i<e;i++) 
	{
		if(group[start[i]]==group[end[i]])
		{
			edge[start[i]][end[i]]=group[start[i]];
		}
		else
		{
			edge[start[i]][end[i]]=0;	
			if(group[end[i]]==temp) continue;
			final[group[start[i]]][index[group[start[i]]]++]=group[end[i]];
			temp=group[end[i]];
		}
	}
	printf("\n\nThe component graph formed is\nadjacency list form of component graph is \n\n");
	for(i=1;i<ncc;i++)
	{
		printf("%d|",i);
		for(j=0;j<index[i];j++)
		{
			if(final[i][j]==0) continue;
			printf("-->%d",final[i][j]);
		}
		printf("\n");
	}
	printf("\nHere the numbers represents the component graph vertices not the actual graph vertices\nContents of these vertices are already mentioned above as Strongly Connected component\n\n");
}
int main()
{
	int ii,jj,n,e,**link,u,v,i;
	int **final,**linkt,*group,*parent;
	int *start,*end,*color,**edge,*ui,*index,*vi,cycles=0,*connect,*uit,ncon=0;
	int *traversal,tt=0,ncc;//ncc stands for number of strongly connected components
	int *finish,clock=0;// n = no of nodes; e = no of edges; link is adjacecy list; 
//edge contains information related to edges i.e. if the age belongs to which SSC or whether it does not goes to any SSC
//start refers to the start of some edge and end refers to the end point of that edge
//groups refers to which SSC gropu a particular node refers to 
//ui is the counter on no of elements in adjacency list corresponding to every node
//storing connected components
//lt is the indedx of traversal which gets updated everytime traversal is updated
	input(&n,&e,&link,&parent,&color,&ui,&linkt,&uit,&finish,&traversal,&edge,&start,&end ,&group,&final,&index);				//function to take input, linkt stands for linking of transpose
	graph_transpose(link,linkt,n,ui,uit);
	connect = (int*)malloc(sizeof(int)*n);
	DFS(link,parent,color,n,e,ui,&cycles,connect,&ncon,0,finish,&clock,traversal,&tt,edge,group,&ncc);
	color_zero(color,n);
	ncon=0;
	cycles=ncon=0;
	DFS(linkt,parent,color,n,e,uit,&cycles,connect,&ncon,1,finish,&clock,traversal,&tt,edge,group,&ncc);
	component(edge,group,start,end,final, n, e,index,ncc);
	
	 
}
