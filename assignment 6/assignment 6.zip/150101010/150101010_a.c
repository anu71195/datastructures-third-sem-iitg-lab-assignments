//NAME :- ANURAG RAMTEKE
//ROLL NO :150101010
#include <stdio.h>
#include <stdlib.h>
//edges start from index=1
void linkage(int**link,int u, int v,int*ui )	//to create adjacency list
{
	link[u][ui[u]++]=v;
}
void input(int * n, int *e,int***link,int**parent,int**color,int**ui,int***linkt,int**uit,int**finish,int**traversal )	//to take input
//to take input and also allocated the required size to the pointer created
{
	int u,i,v;
	char dummy;
	printf("Type the no of vertices=");
	scanf("%d",n);	
	printf("Type the no of edges=");
	scanf("%d",e);
	int k =*n;
	k=2*k;
	*parent = (int*)malloc(sizeof(int)*(*(n+1)));	
	*traversal=	(int*)malloc(sizeof(int)*(*(n+1)));
	*color = (int*)malloc(sizeof(int)*(*(n+1)));
	*finish= (int*)malloc(sizeof(int)*(k+2));
	for(i=0;i<(*n);i++) (*parent)[i+1]=(*color)[i+1]=0;
	(*ui) = (int*)malloc(sizeof(int)*((*n)+1));
	(*uit) = (int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++)					//ui is the counter on no of elements in adjacency list corresponding to every node
	{
		(*ui)[i+1]=1;
		(*uit)[i+1]=1;
	}
	*linkt=(int**)malloc(sizeof(int*)*((*n)+1));
	*link = (int**)malloc(sizeof(int*)*((*n)+1));		//stores adjacency list
	for(i=0;i<(*n);i++) (*linkt)[i+1]=(int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<(*n);i++) (*link)[i+1]=(int*)malloc(sizeof(int)*((*n)+1));
	printf("Give the edges\n");
	for(i=0;i<(*e);i++)
	{

		scanf("%d",&u);
		//scanf("%c",&dummy);	
		scanf("%d",&v);
		linkage(*link,u,v,*ui);				//to create adjacency list
	}
}
void print_cycle(int u,int v,int **link,int*parent)
//prints the cycles in the graph
{
	if(u==v)  printf("%d ",u);
	else 
	{
		print_cycle(u,parent[v],link,parent);
		printf("%d ",v);
	}
}
void DFS_visit(int i,int**link,int*ui,int*color,int*parent,int*cycles,int*connect,int*ncon,int flag,int*finish,int *clock,int*traversal,int*tt,int*lt)
//traverses all the nodes in the graph in DFS manner
{
	if(i>0) connect[(*ncon)++]=i; 			//storing connected components
	if ( flag ==0) if(i>0) printf("%d  ",i);
	else if (flag==1) 
	{
				traversal[(*lt)]=i;
				(*lt)++;
	}
	int j;
	color[i]=1;
	for(j=0;j<ui[i];j++)	
	{
		if(color[link[i][j+1]]==0)
		{
		 	parent[link[i][j+1]]=i;
			DFS_visit(link[i][j+1],link,ui,color,parent,cycles,connect,ncon,flag,finish,clock,traversal,tt,lt);
		}
		else if(color[link[i][j+1]]==1)
		{
			if(parent[link[i][j+1]]==i||parent[i]==link[i][j+1]) continue;
			else 
			{
				(*cycles)++;
			}			
		}
	}
	color[i]=2;
	if(flag ==0)finish[(*clock)++]=i;
}

void DFS(int ** link,int*parent,int*color,int n, int e,int*ui ,int*cycles,int*connect,int*ncon,int flag,int*finish,int*clock,int *traversal,int*tt)
// differentiates between the grpah and transpose graph using the flag passed into it in arguments  and tells the coonnected components and also find all the strongly connected components
{
	int i=0,j=0,k,t=1,lt=0;
	
if(flag==0)	for(i=0;i<n;i++)	
	{
		if(color[i+1]==0) 
		{
			DFS_visit(i+1,link,ui,color,parent,cycles,connect,ncon,flag,finish,clock,traversal,tt,&lt);	//ui is the counter on no of elements in adjacency list corresponding to every node
			t++;	
			*ncon=0;
		}
	}
else if(flag==1)	{ while((*clock)>0)	
	{ 
		i=finish[*clock-1];
		if(color[i]==0) 
		{
			DFS_visit(i,link,ui,color,parent,cycles,connect,ncon,flag,finish,clock,traversal,tt,&lt);	//ui is the counter on no of elements in adjacency list corresponding to every node
			if(flag==1) printf("\nStrongly connected  components %d=  ",t);			//ncon is the no of connected elements in connected set of vertices
			t++;	
			if(flag==1) for(k=0;k<*ncon;k++) printf("%d  ",connect[k]);			//prints connected components
			if(flag ==1) printf("\n");
			*ncon=0;
		}
		(*clock)--;
	}}
}

void graph_transpose(int ** link,int**linkt,int n,int *ui,int*uit)
//transposes the given graph link into a new graph linkt
{
		int i,j;
		for(i=1;i<=n;i++) for(j=1;j<ui[i];j++) linkt[link[i][j]][uit[link[i][j]]++] =i;
}
void color_zero(int*color,int n)
//makes all the nodes equal to zero
{
	int i;
	for(i=0;i<n;i++) color[i+1]=0;
}
int main()
{
	int ii,n,e,**link,**linkt,*parent,*color,*ui,*vi,cycles=0,*connect,*uit,ncon=0,*traversal,tt=0,*finish,clock=0;// n = no of nodes; e = no of edges; link is adjacecy list; 
//clock keeps track of finishing time of the nodes and link is the graph and linkt is the transpose graph 
	input(&n,&e,&link,&parent,&color,&ui,&linkt,&uit,&finish,&traversal );				//function to take input, linkt stands for linking of transpose
	graph_transpose(link,linkt,n,ui,uit);
	connect = (int*)malloc(sizeof(int)*n);
	printf("The DFS traversal is\n");
	DFS(link,parent,color,n,e,ui,&cycles,connect,&ncon,0,finish,&clock,traversal,&tt);
	color_zero(color,n);
	ncon=0;
	cycles=ncon=0;
	DFS(linkt,parent,color,n,e,uit,&cycles,connect,&ncon,1,finish,&clock,traversal,&tt);
}
