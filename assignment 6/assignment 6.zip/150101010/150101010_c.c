//NAME :- ANURAG RAMTEKE
//ROLL NO: - 150101010
#include <stdio.h>
#include <stdlib.h>

void matrix_linkage(int u, int v,int w,int**matrix)
//creates the adjacency matrix
{
	matrix[u][v]=w;
	matrix[v][u]=w;	;
}

void input(int*n,int*e,int***matrix,int**key,int**parent,int*max_key,int**include)
//input function takes the input and also allot space to the pointers
{
	int u,v,w,i,j;
	printf("Give the no of vertices:");
	scanf("%d",n);
	printf("Give the no of edges:");
	scanf("%d",e);
	printf("Give the edges and weight\n");
	*key=(int*)malloc(sizeof(int)*((*n)+1));
	*parent=(int*)malloc(sizeof(int)*((*n)+1));
	*include=(int*)malloc(sizeof(int)*((*n)+1));
	*matrix=(int**)malloc(sizeof(int*)*((*n)+1));
	for(i=0;i<*n;i++) (*matrix)[i+1]=(int*)malloc(sizeof(int)*((*n)+1));
	for(i=0;i<*n;i++) for(j=0;j<*n;j++) (*matrix)[i+1][j+1]=0;
	for(i=0;i<*e;i++) 
	{
		scanf("%d%d%d",&u,&v,&w);
	// u and v are starting and ending nodes of edges and w is the weight of that edge
		if(w>*max_key) *max_key=w;
		matrix_linkage(u,v,w,*matrix);
	}
}
int min_key(int*key,int*include,int max_key,int n)
//returns the node which is not included in the graph and is having the minimum key
{
	int i,min_edge=max_key+1,min;
	for(i=0;i<n;i++) 	if(include[i+1]==0 && key[i+1]<min_edge)
				{
					min=i+1;
					min_edge=key[i+1];				
				}
	return min;
}
void MST_PRIM(int**matrix,int n,int*key,int*parent,int max_key,int root )
//prints the adjacency matrix of the graph and finds the parent of all the nodes and then prints the parent of all nodes after it executes prim's algorithm along with its weight
{
	int i,min,j,include[n+1];
	//includes tell whether the node is included in the MST or not
	printf("\n	Adjacency matrix formed is\n");
	printf("\n |\t");
	for (i=0;i<n;i++) printf("%d\t",i+1);
	printf("\n");
	printf("-+------");
	for (i=0;i<n;i++)printf("--------");
	printf("\n");
	for(i=0;i<n;i++) 
	{	printf("%d|\t",i+1);
		for(j=0;j<n;j++) printf("%d\t",matrix[i+1][j+1]);
		printf("\n");
	}
	printf("\n");
	for(i=0;i<n;i++)	
		{
			key[i+1]=max_key+1;
			include[i+1]=0;
		}
	key[root]=0;
	parent[root]=-1;
	for(i=0;i<n-1;i++)
	{
		min=min_key(key,include,max_key,n);

		include[min]=1;
		for(j=0;j<n;j++)
		{
			if(matrix[min][j+1] && include[j+1] == 0 && matrix[min][j+1]<key[j+1])
								{ 
									parent[j+1]=min; 
									key[j+1]=matrix[min][j+1];
								}
		}
	}
	 printf("Edge   Weight\n");
	 for (i = 2; i <= n; i++)
      	 printf("%d - %d    %d \n", parent[i], i, matrix[i][parent[i]]);
}
int main()
{
	int n,e,**matrix,*key,*parent,max_key=0,*include;
	//include means whether some vertex is included in MST or no	
	//n is no of vertices
	//e is no of edges
	//matrix will contain the adjacency matrix of the graph
	input(&n,&e,&matrix,&key,&parent,&max_key,&include);
	MST_PRIM(matrix,n,key,parent,max_key,1);
}
