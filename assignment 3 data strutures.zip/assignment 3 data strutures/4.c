#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int random_generator() { return rand()%100;}	//generates a random value below 100

typedef struct binary_tree
{
	int data;
	struct binary_tree *left, *right;
	
} node;
 
void insert(node** head, int value )			//inserts value into the binary search tree
{
	node *temp = NULL;
	if(*head ==NULL)
	{
		temp = (node *)malloc(sizeof(node));
        	(*temp).left = (*temp).right = NULL;
        	(*temp).data = value;
        	*head = temp;
	}
	else if(value<=(*(*head)).data)
	{
		insert(&(*(*head)).left,value);
	}
	else if (value>(*(*head)).data)
	{
		insert(&(*(*head)).right,value);
	}
	
}
/*int max_levels(node * head,int * max,int* i)//max-1 from this gives the value for the maximum level of the leaf node
{
	
	if (head ==NULL) 
	{
		if((*max)<*i) (*max)=*i;
		return 0;
	}
	else 	(*i)++;
	if(max_levels((*head).left,max,i)) (*i)--;
	if(max_levels((*head).right,max,i))(*i)--;	
	return 1;
}
int max2_levels(node * head, int * max2, int * i, int max,int*flag,int*flag2)			//gives the second biggest value of all the leaf nodes or the repeated biggest node
{

	if (head ==NULL) 
	{
		if((*i)==max&&*flag==0) {*flag =1 ;}
		else if ((*i)==max&&*flag==1&&*flag2==0) *flag2=1;
		else if((*max2)<*i) (*max2)=*i;
		return 0;
	}
	else 	(*i)++;
	int temp=max2_levels((*head).left,max2,i,max,flag,flag2);
	if(temp) (*i)--;
	temp=max2_levels((*head).right,max2,i,max,flag,flag2);
	if(temp)(*i)--;	
	return 1;
}*/
void LCA(node * head,int v, int w,int*lca,int*dlca,int*count)			//gives the lowest common ancestor of the nos v and w and lca gives the node which is the LCA and dlca gives the level of it
{
	(*dlca)++;
	if((*head).data>v&&(*head).data>w){(*count)+=2; LCA((*head).left,v,w,lca,dlca,count);}
	else if((*head).data<v&&(*head).data<w) {*count+=4;LCA((*head).right,v,w,lca,dlca,count);}
	else   {(*lca)=(*head).data;*count+=4;}
/*
1)
Every time the function is called max comparisons = 4
max number of times the function will be called = n-1
min number of times =log(n) (in many cases even less than log(n))
*/

}
void leaves(node * head,int * i,int * count)			//i from this function gives the no of leaves
{
	if(head ==NULL) {*count++;return;}
	if((*head).left==NULL && (*head).right==NULL) 
	{
		(*i)++;
		*count+=2;
		return ;
	}
	leaves((*head).left,i,count);
	leaves((*head).right,i,count);
/*
2)
max no of comparisons in the function =2;
max no of times the function will be called = n;
min no of times the function will be caleld =n;
*/
}
int leaves_value(node * head,int *i,int * l_value,int * j,int*depth,int*count)		//l_value gives the value of all leaves and j_depth gives depth of all leaves form binary search tree
{
	if(head==NULL) {*count++;return 0;}
	if ((*head).left ==NULL&&(*head).right==NULL) 
	{
		*count+=2;
		l_value[(*i)]=(*head).data;
		depth[(*i)]=*j;
		(*i)++;
		return 0;
	}
	(*j)++;
	if(leaves_value((*head).left,i,l_value,j,depth,count)){(*j)--; ;(*count)++;}
	if(leaves_value((*head).right,i,l_value,j,depth,count)) {(*j)--;(*count)++;}
	return 1;
/*
3)
max no of comparisons = 5;
max no of calls of function = n;
min no of calls of function = log(n) (in few cases can be even lesser than log(n))
*/
}
/*
TIME COMPLEXITY
from 1,2 and 3
max time complexity =4*(n-1)+2*n+5*n=O(n)
min time complexity = 4*log(n)+2*n+5*log(n)=O(log(n)+O(n)=O(log(n)+log(2^n))=O(log(n*2^n))
here the coefficient in min is less than max.

*/

int main()
{	int repeat[1000]={0},maximum,k=0,maximum2,max2,flag2,*l_value,n_leaves,j=0,*depth,lca,diameter=0,dlca,count;
	node * head;
		head=NULL;
		int i=0,max=0,min=0,flag=0,temp;
		printf("the nodes are:-\n");
		for(i=0;i<100;i++) 	{temp = random_generator();insert(&head,temp);printf("%d ",temp); }	//generates 100 values for binary search tree
		i=0;
		leaves(head,&i,&count);									//i from this function gives the no of leaves
		printf("\nno of leaves=%d\nThe leaves are :-",i);
		l_value=malloc(sizeof(int)*(i));							
		depth=malloc(sizeof(int)*i);
		n_leaves=i;										//n_leaves is equal to the no of leaves in the binary search tree
		i=0;
		leaves_value(head,&i,l_value,&j,depth,&count);					//l_value gives the value of all leaves and j_depth gives depth of all leaves form binary search tree
		for(i=0;i<n_leaves;i++) printf(" %d ",l_value[i]);
			printf("\n");
 		for(i=0;i<n_leaves-1;i++) for(j=i+1;j<n_leaves;j++)
	 				{
 
						LCA(head,l_value[i],l_value[j],&lca,&dlca,&count);		//lca gives the node which is the LCA and dlca gives the level of it
						dlca--;
						if(diameter<depth[i]+depth[j]-2*dlca)diameter=depth[i]+depth[j]-2*dlca;
						dlca=0;
 					}
		printf("Diameter=%d\n",diameter);
		printf("the no of comparisons = %d\n",count);
}
