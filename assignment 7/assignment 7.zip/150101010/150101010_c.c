//NAME := ANURAG RAMTKE
//ROLL NO: = 150101010
#include <stdio.h>
#include <stdlib.h>
typedef struct node node;
struct node
{
	int value;
	node* parent;
	int color;
};
node* create_node(int i)
//creates node with certain value in it represent as i in it
{
	node *object;
	object=(node*)malloc(sizeof(node));
	object->value=i;
	object->parent=object;
	object->color=0;
	return object;
	
}
//color=0 represents that it is in the set T
//color=1 represents that it is takes from the set and put it in another set
//color=2 represents that it is excluded from that state also
int extract_min(node**head,node**T,int n)
//extracts the minimum of the set and returns it as the value variable
{
	int value,i,min=n+1;
	value = (*head)->value;
	(*head)->color=2;
	for(i=0;i<n;i++)
	{
		if(T[i+1]->color==1)	
		{
			if(T[i+1]->value<min) min=T[i+1]->value;
		}
	}
	*head=T[min];
	return value;
}
void UNION(node**head,int value,node**T)
//unions the set by union by rank and path compression method
{
	if((*head)->value>value)		
	{
		(*head)->parent=T[value];
		*head=T[value];
	}	
	else
	{
		T[value]->parent=*head;
	}	
}
void print(int * extracted, int m)
//prints the disjoint set
{
	int i;
	for(i=0;i<m;i++)
	{
		printf("%d ",extracted[i]);
	}
}
int main()
{
	int n,m,i,it,*extracted,value=0,j=0,k,temp,zeroes=1,val,counter=0;	
	char c[100],dummy;
//n is the no of insert options
//m is the no of extract options
//extracted is hte set of the extracted elemenets
//i is just a counterin most places
//it is also a counter in one place
	node ** T,*head;
//t is the initial set
//head is the root of the another set which will be formed after including nodes
	printf("Give the value of n(no of insert options):");
	scanf("%d",&n);
	printf("Give the value m(no of extract optinos):");
	scanf("%d",&m);
	int input[n+m];
	//will stores input by the user
	extracted=(int*)malloc(sizeof(int)*n);
	T=(node**)malloc(sizeof(node*)*(n+1));
	head=(node*)malloc(sizeof(node));
	for(i=0;i<n;i++)
	{
		T[i+1]=create_node(i+1);
	}		
	scanf("%c",&dummy);
	printf("Give the inputs:\n");
	for(it=0;it<(n+m);it++)//takes the input from the user
	{
		scanf("%s",c);

		for (i=0;i<100;i++)
					{
						if(c[i]=='\0'||c[i]=='\n') break;	
						if(isdigit(c[i]))
						{
		 					temp++;
						}
	
					}
		temp--;

		for (i=0;i<100;i++)
					{
						if(c[i]=='\0'||c[i]=='\n') break;	
						if(isdigit(c[i]))
						{
		 					for(j=0;j<temp;j++) zeroes*=10;
							temp--;
							val=c[i]-48;
							value+=val*zeroes;
							zeroes=1;
					
						}
	
					}
		input[counter++]=value;
		value=0;
		temp=0;
		zeroes=1;

	}
//for(i=0;i<counter;i++) printf("%d\t",input[i]);
printf("\n");

	for(i=0;i<counter;i++)
	{
		value=input[i];
		if(value==0)//extracts the elements
		{
			extracted[j++]	= extract_min(&head,T,n);//extracted elemenets		
		}
		else 
		{
			if(T[value]->color==1) 
			{
				printf("ERROR-DUBLICATE ENTRY and at that time it is %d",i);//error term
				return;
			}
			if(i==0) 
			{
				head=T[value];
			}
			else 
			{
				UNION(&head,value,T);
			}
			T[value]->color=1;
		}
	}
	printf("The extracted elements are:\n");
	print(extracted,m);//prints the disjoint sets

		

}
