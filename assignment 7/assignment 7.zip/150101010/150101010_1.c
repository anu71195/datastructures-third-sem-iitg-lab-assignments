//NAME := ANURAG RAMTKE
//ROLL NO: = 150101010
#include <stdio.h>
#include <stdlib.h>
typedef struct node node;
struct node
{
	int value;
	int tag;
	node*root;
	node* next;
};
node * create_node(int value,int tag)
//creates an individual node with value and tags in it
{
	node * object;
	object=(node*)malloc(sizeof(node));
	(*object).value=value;
	(*object).next=NULL;
	(*object).tag=tag;
	(*object).root=object;
	return object;	
}
int make_set(node**head,node**tail,node**repr,int*size,int k)
//make set will make the set of all the nodes that is it will make disjoint nodes of all the elements
{
	int tfortemp,i,max=0;
	for(i=0;i<k;i++) 
	{
		scanf("%d",&tfortemp);
		if(tfortemp>max) max=tfortemp;
		head[i]=create_node(tfortemp,i);
		tail[i]=head[i];
		repr[i]=head[i];
		size[i]=1;
	}
	return max;
}
int find_set(int i,node**rep)
//finds the set of the element specified
{
	return rep[i]->value;
}
void print_set(node**head,node**rep,int k, int max)
//prints the entire disjoint sets
{
	int i,j;
	printf("First column shows the representative elements\n");
	for(i=0;i<k;i++)
	{
		if(head[i]==NULL) continue;	
		printf("%d\t",head[i]->value);	
		for(j=0;j<=max;j++)
		{
			if(rep[j]==NULL) continue;
			if(head[i]->value==j) continue;
			if(head[i]->value==rep[j]->value)	printf("%d\t",j);
		}
		printf("\n");
	}
	
}
void UNION(int a, int b,node**head,node**tail,node**rep,int*size,int methods,int k, int max)
//it will union the two disjoint sets by wuh or by normal methods depending upon the variable methods
{
	node *a1,*b1;
	int i;
	a1=rep[a];//a1 will store the address of the root of the set where a is present
	b1=rep[b];//b1 will store the address of the root of the set where b is present	
	if (methods==0)
	{
		//it does by union by wuh (weighted union heuristic) method
		if(size[a1->tag]>=size[b1->tag])
		{		
			for(i=0;i<=max;i++)
			{
				if(rep[i]==b1)	rep[i]=a1;
			}
			b1->root=a1;
			a1->next=b1;
			//rep[b]=a1;
			head[b1->tag]=NULL;
			size[a1->tag]=size[a1->tag]+size[b1->tag];
			tail[a1->tag]=b1;
		}
		else
		{
			for(i=0;i<=max;i++)
			{
				if(rep[i]==a1)	rep[i]=b1;
			}
			a1->root=b1;
			b1->next=a1;
			//rep[b]=a1;
			head[a1->tag]=NULL;
			size[b1->tag]=size[a1->tag]+size[b1->tag];
			tail[b1->tag]=a1;
		}
	}
	else//this method is normal method i.e. where the first specified element becomes the parent of second one
	{
		for(i=0;i<=max;i++)
		{
			if(rep[i]==b1)	rep[i]=a1;
		}
		b1->root=a1;

		a1->next=b1;
		//rep[b]=a1;
		head[b1->tag]=NULL;
		size[a1->tag]=size[a1->tag]+size[b1->tag];
		tail[a1->tag]=b1;
		
	}

	print_set(head,rep,k,max);
}
int main()
{
	int  *size,k,methods,menu,max,i,find_value,j,a,b;
	//rep is an array of representative of all the elements
	//head is the representative element of each set 
	//size s is the height of the set
	//menu is the variable that will store optino in side the loop
	//method will store type of method to implement
	//find value stores the set osme element will contain
	printf("Give the no of elements:");
	scanf("%d",&k);
	node **head=(node**)malloc(sizeof(node*)*k);
	node **tail=(node**)malloc(sizeof(node*)*k);
	node **repr=(node**)malloc(sizeof(node*)*k);
	size=(int*)malloc(sizeof(int)*k);
	printf("Give those elements:\n");
	max=make_set(head,tail,repr,size,k);
	//max will store the maximum element of the set
	node **rep=(node**)malloc(sizeof(node*)*(max+1));
	for(j=0;j<max+1;j++) rep[j]=NULL;
	for(i=0;i<k;i++) 	rep[repr[i]->value]=repr[i];
	free(repr);
	printf("0/1	: 	WUH/normal:=	");	
	scanf("%d",&methods);
	if(methods>=2) 
	{
		printf("ERROR - wrong input\n");
		return;
	}
	while(1)
	{
		printf("\n0/1/2	:	find_set/union/exit:=	");
		scanf("%d",&menu);
		if(menu==2) break;//breaks the program
		else if(menu>2) //error term
		{
			printf("ERROR - Wrong input\n");
		}
		else if(menu==0)//finds the set of some specified element
		{
			printf("\nGive the element to find its set:");
			scanf("%d",&i);
			find_value=find_set(i,rep);
			printf("the set of %d is %d\n",i,find_value);
		}
		else if(menu==1)//union of the two specified elements
		{
			printf("\nGive the two elements:");
			scanf("%d %d",&a,&b);
			UNION(a,b,head,tail,rep,size,methods,k,max);
		}
	}
		
}
