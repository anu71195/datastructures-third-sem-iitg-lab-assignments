//NAME := ANURAG RAMTKE
//ROLL NO: = 150101010
#include <stdio.h>
#include  <stdlib.h>

int INPUT(int * input,int k)
//takes input from teh user and returns the maximum of them 
{
	int max=0,i,take;
	for(i=0;i<k;i++)
	{
		scanf("%d",&take);
		input[i]=take;
		if(max<take) max=take;
	}
	return max;
	
}
void make_set(int k, int*input, int*p,int*rank,int*root)
//makes the set that is assigns the node of each element and thus making the disjoing set forests
{
	int i;
	for(i=0;i<k;i++)
	{
		p[input[i]]=input[i];//parent term
		rank[input[i]]=0;//rank of the set term
		root[input[i]]=10;//binary term for root either 10 or 0 , 10 means it is a root 0 means it is not the root
	}	
}
int find_set(int x, int*p)
//find the sets of specified element
{
	if(x==p[x]) return x;
	else return find_set(p[x],p);
}
void print_set(int * input, int * p, int k, int * root)
//prints the set of disjoint sets
{
	int i,j;
	for ( i =0;i<k;i++)
	{
		if(root[input[i]]==10)
		{
			printf("%d\t",input[i]);
			for(j=0;j<k;j++)
			{
				if(input[i]==input[j]) continue;
				if(input[i]==find_set(input[j],p)) printf("%d\t",input[j]);
				
			}
			printf("\n");
		}
	}
}
void UNION(int a, int b, int*input,int *p, int * rank, int k, int choice,int*root)
//it does union by three methods given by choice i.e. either disjoint set forests, union by rank or by union by rank and path compression method
{
	int a1,b1,i;
	a1=find_set(a,p);
	b1=find_set(b,p);
	if(choice==0)//disjoint set forests
	{
		p[b1]=a1;
		root[b1]=0;
 		if(rank[a1]<=rank[b1])	rank[a1]=rank[b1]+1;
	}
	else if(choice==1)//union by rank method
	{
		if(rank[a1]<rank[b1]) 
		{
			p[a1]=b1;
			root[a1]=0;
		}
		else if(rank[b1]<=rank[a1])
		{
			p[b1]=a1;
			root[b1]=0;
			if(rank[b1]==rank[a1]) rank[a1]+=1;
		}
	}
	else if(choice ==2)//union by rank and path compression
	{
		if(rank[a1]<rank[b1]) 
		{
			p[a1]=b1;
			root[a1]=0;
			for(i=0;i<k;i++)
			{
				if(p[input[i]]==a1) p[input[i]]=b1;
			}
		}
		else if(rank[b1]<=rank[a1])
		{
			p[b1]=a1;
			root[b1]=0;
			if(rank[b1]==rank[a1]) rank[a1]+=1;
			for(i=0;i<k;i++)
			{
				if (p[input[i]]==b1) p[input[i]]=a1;
			}
		}
	}
printf("The first column represents the representative elements\n");
print_set(input, p, k, root);
}
int main()
{
	int k,*p,*rank,*input,max,choice,menu,x,find_value,a,b,*root;
//k is the no of element sthat the uer will give
//p is the parent list
//rank is the rank list
//max stores the maximum of those element
//choice is the choice of methods to implement the algo
//menu isthe choice what to do in side the loop
//find_value returns the find set value i.e. the element belongs to which set
//root is the term where the root of the sets are present
	printf("Give the no of elements:");
	scanf("%d",&k);
	printf("Give those elements\n");
	input=(int*)malloc(sizeof(int)*k);
	max=INPUT(input,k);
	p=(int*)malloc(sizeof(int)*(max+1));
	rank=(int*)malloc(sizeof(int)*(max+1));
	root=(int*)malloc(sizeof(int)*(max+1));
	make_set(k,input,p,rank,root);//makes the set that is assigns the node of each element and thus making the disjoing set forests
	printf("0/1/2 	: 	disjoint set forests/union by rank/union by rank and path compression:=\t");
	scanf("%d",&choice);
	if(choice>2) //error term
	{
		printf("ERROR - wrong input");
		return;
	}
	while(1)
	{
		printf("\n0/1/2 	: 	find set/union/exit:=\t");
		scanf("%d",&menu);
		if(menu==2) break;//exit term
		else if(menu>2) //error term
		{
			printf("ERORR - wrong input\n");
			
		}
		else if(menu==0) //find set menu
		{
			printf("\nGive the element:");
			scanf("%d",&x);
			find_value=find_set(x,p);
			printf("the element %d belongs to the set of %d\n",x,find_value);
		}
		else if(menu ==1)//union menu
		{
			printf("\nGive both elements:");
			scanf("%d %d",&a,&b);
			UNION(a,b,input,p,rank,k,choice,root);
		}
		
	}
}
