#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int random_generator() { return rand()%100;}			//generates a random value below 100

typedef struct binary_tree
{
	int data;
	struct binary_tree *left, *right;
	
} node;
 
void insert(node** head, int value )		//inserts value into the binary search tree
{
	node *temp = NULL;
	if(*head ==NULL)
	{
		temp = (node *)malloc(sizeof(node));
        	(*temp).left = (*temp).right = NULL;
        	(*temp).data = value;
        	*head = temp;
	}
	else if(value<=(*(*head)).data)
	{
		insert(&(*(*head)).left,value);
	}
	else if (value>(*(*head)).data)
	{
		insert(&(*(*head)).right,value);
	}
}
void LCA(node * head,int v, int w,int*lca,int*count)		//gives the lowest common ancestor of the nos v and w
{
	if	((*head).data>v&&(*head).data>w) {LCA((*head).left,v,w,lca,count);*count+=2;}		//Everytime the function is called at max 4 comparisons are made
	else if((*head).data<v&&(*head).data<w) {LCA((*head).right,v,w,lca,count);*count+=4;}		//at max the function is called will be n and min will be log(n) where n is the no of nodes
	else   {(*lca)=(*head).data;*count+=4;}		//max time will be 4n and min will be 4log(n) i.e. max and min time complexity will be O(n) and O(log(n)) respectively						

}
int main()
{	int j,repeat[1000]={0},maximum,k=0,v,w,lca,count=0;
	node * head;
	 
		head=NULL;
		int i=0,max=0,min=0,flag=0,temp;
		for(i=0;i<10;i++) 	{temp = random_generator();insert(&head,temp);printf("%d ",temp); }	//generates 100 values for binary search tree
		printf("type the first node");
		scanf("%d",&v);											//v is the first node whose LCA has to be find out
		printf("type the second node");
		scanf("%d",&w);											//w is the second node whose LCA has to be find out
		LCA(head,v,w,&lca,&count);										//lca stores  LCA of v and w 
		printf("lca =%d",lca);
		printf("the TOTAL comparisons will be equal to %d",count);
}
