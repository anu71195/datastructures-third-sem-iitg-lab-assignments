#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int random_generator() { return rand()%100;}				//generates a random value below 100

typedef struct binary_tree						
{
	int data;
	struct binary_tree *left, *right;
	
} node;
 
void insert(node** head, int value )					//inserts value into the binary search tree
{
	node *temp = NULL;
	if(*head ==NULL)
	{
		temp = (node *)malloc(sizeof(node));
        	(*temp).left = (*temp).right = NULL;
        	(*temp).data = value;
        	*head = temp;
	}
	else if(value<=(*(*head)).data)
	{
		insert(&(*(*head)).left,value);
	}
	else if (value>(*(*head)).data)
	{
		insert(&(*(*head)).right,value);
	}
	
}
int max_levels(node * head,int * max,int* i)				//max-1 from this gives the value for the maximum level of the leaf node
{
	
	if (head ==NULL) 
	{
		if((*max)<*i) (*max)=*i;
		return 0;
	}
	else 	(*i)++;
	if(max_levels((*head).left,max,i)) (*i)--;
	if(max_levels((*head).right,max,i))(*i)--;	
	return 1;
}
int min_levels(node * head, int * min, int * i,int * flag)			//min-1 from this gives the value for the minimum level of the leaf node
{
	(*i)++;
	if(head==NULL)
	{
		 return 0;
	}
	if((*head).left == NULL && (*head).right == NULL) 
	{
		if(*flag==0)
		{
			(*min)=*i;
			*flag =1;
		}
		if((*min)>*i) (*min)=*i;
	}
	min_levels((*head).left, min , i,flag);(*i)--;
	min_levels((*head).right, min , i,flag);(*i)--;
}
int main()					
{	int j,repeat[1000]={0},maximum,k=0;
	printf("serial no\tmax\tmin\n");
	node * head;
	for (j=0;j<50;j++)
	{
		head=NULL;		
		int i=0,max=0,min=0,flag=0,temp;
		for(i=0;i<100;i++) 	{temp = random_generator();insert(&head,temp); }			//generates 100 values for binary search tree
		i=0;
		max_levels(head,&max,&i);								       //max-1 from this gives the value for the maximum level of the leaf node
		i=0;
		min_levels(head,&min,&i,&flag);									//min-1 from this gives the value for the minimum level of the leaf node
		repeat[max-min]+=1;										//repeat means the frequency of how many times (max-min ) value repeated
		if(maximum<max-min) maximum = max-min;								//j+1 is the serial no
		printf("%d\t\t%d\t%d\n",j+1,max-1,min-1); 
	}
	printf("\nSerial no\tdifference\tfrequency\n");	
	j=0;
	while(1)
	{
		if(repeat[j++]==0) continue;
		printf("%d\t\t   %d                %d\n",k+1,j-1,repeat[j-1]);				//k+1 is the serial no, j-1 is the difference between max and min, repeat is the frequency
		if(j-1==maximum) break;
		k++;
	}
}
